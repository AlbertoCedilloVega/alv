package controladores;

import dao.BaseDatos;
import dao.FabricaDao;
import dao.TablaLibro;
import java.io.IOException;
import java.io.PrintWriter;
import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Libro;

public class ControladorFrontalLibros extends HttpServlet {
    private BaseDatos baseDatos;
    private String resultado;

    @Override
    public void init(ServletConfig config) throws ServletException {
        //super.init(config);
        String nombre;
        String usuario;
        String password;
        nombre = config.getInitParameter("nombre");
        usuario = config.getInitParameter("usuario");
        password = config.getInitParameter("password");
        baseDatos = FabricaDao.getBaseDatos(nombre, usuario, password);
        resultado=baseDatos.hacerConexion();

    }

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        System.out.println("conecion"+resultado);
        String recurso=null;
        HttpSession sesion= request.getSession();
        if (resultado.equals("exito")) {
            String opcion=request.getParameter("opcion");
            String isbn=null;
            switch(opcion){
                case "registrar":
                    isbn=request.getParameter("isbd");
                    if (isbn==null) {
                        Libro libro = new Libro();
                        libro.setIsbn(isbn);
                        libro.setTitulo(request.getParameter("titulo"));
                        libro.setEdicion(request.getParameter("edicion"));
                        libro.setEditorial(request.getParameter("editorial"));
                        libro.setAutor(request.getParameter("autor"));
                        sesion.setAttribute("mensaje","mensaje");
                        
                    } else {
                        sesion.setAttribute("mensaje", "este libro ya se ecuentra registrado");
                    }
                    response.sendRedirect("VISTA/JSP/mensajes.jsp");
                    recurso="VISTA/JSP/mensajes.jsp";
                    break;
                case "consultar":
                    isbn=request.getParameter("isbd");
                    Libro libro=null;//tablaLibro.getLibro
                    if(libro!=null){
                        sesion.setAttribute("libro", "libro");
                        response.sendRedirect("VISTA/JSP/verLibro.jsp");
                    }else{
                        sesion.setAttribute("mensaje", "este libro no se encuentra");
                        response.sendRedirect("VISTA/JSP/mensajes.jsp");
                    }
                    
                    break;
                    
                    
                            
                    
                
            }
            //recurso="VISTA/JSP/mensajes.jsp";
        } else {
            recurso="Errores";
        }
        sesion.setAttribute("mensaje",resultado);
        response.sendRedirect(recurso);
        //request.setAttribute("mensaje", resultado);
        //RequestDispatcher rd=request.getRequestDispatcher(recurso);
        //rd.forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
