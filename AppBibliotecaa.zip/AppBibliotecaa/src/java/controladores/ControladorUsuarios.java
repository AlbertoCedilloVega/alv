package controladores;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Usuario;

/**
 *
 * @author Claudia
 */
@WebServlet(name = "ControladorUsuarios", urlPatterns = {"/ControladorUsuarios"})
public class ControladorUsuarios extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("en el controlador");
        String peticion = request.getParameter("solicitud");
        switch (peticion) {
            case "registrarUsuario":
                Usuario usuario = new Usuario();
                String nombre = request.getParameter("nombre");
                String ap = request.getParameter("ap");
                String am = request.getParameter("am");
                int edad=Integer.parseInt(request.getParameter("edad"));
                String domicilio=request.getParameter("domicilio");
                
                usuario.setNombre(nombre);
                usuario.setAp(ap);
                usuario.setAm(am);
                usuario.setEdad(edad);
               // usuario.setDomicilio(domicilio);
                
                request.setAttribute("usuario",usuario);
                RequestDispatcher rdVisualizarUsuario= request.getRequestDispatcher("ServletVerUsuario");
                rdVisualizarUsuario.forward(request, response);
                

                break;
        }
      
     
     
    }

}
