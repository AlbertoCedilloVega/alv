/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class BaseDatos {

    private Connection conexion;
    private String nombre;
    private String usuario;
    private String password;

    public BaseDatos(String nombre, String usuario, String password) {
        this.nombre = nombre;
        this.usuario = usuario;
        this.password = password;
    }

    public String hacerConexion()  {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/" + nombre, usuario, password);
            return "exito";
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar el driver");
            return "error " + e.getMessage();
        } catch (SQLException g1) {
            JOptionPane.showMessageDialog(null, "Error al cargar ");
            return "error " + g1.getMessage();
        }

    }

    public void cerrar() {
        try {
            if (conexion != null) {
                conexion.close();
            }
        } catch (Exception e) {

        }
    }
    public Connection getConexion(){
        return conexion;
    }
}
