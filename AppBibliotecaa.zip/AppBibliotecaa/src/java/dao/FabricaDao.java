/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Claudia
 */
public class FabricaDao {
    
    private static BaseDatos baseDatos;
    
    public static BaseDatos getBaseDatos(String nombre, String usuario,String password){
        
        if (baseDatos==null) {
            baseDatos= new BaseDatos(nombre, usuario, password);
        }
        return baseDatos;
    }
    
}
