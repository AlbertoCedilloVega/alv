package dao;

import modelo.Libro;


public class Principal {
    
    public static void main(String[] args) {
        BaseDatos baseDatos = FabricaDao.getBaseDatos("biblioteca", "root", "");
        System.out.println(baseDatos.hacerConexion());
        
        TablaLibro tablaLibro = new TablaLibro(baseDatos.getConexion());
        Libro libro = new Libro();
        
        libro.setIsbn("123456");
        libro.setTitulo("Miiriiam Mora");
        libro.setAutor("Miriam Mora");
        libro.setEditorial("Guillen");
        libro.setEdicion("1");
        
        System.out.println(tablaLibro.registrar(libro));
    }
    
}
