package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Libro;

public class TablaLibro {
    private Connection conexion;
    private Statement statement;
    private ResultSet resulSet;
    
    public TablaLibro(Connection connection){
        this.conexion = connection;
        crearSentencia();
    }
    
    public void crearSentencia(){
        try {
            statement = conexion.createStatement();
        } catch (SQLException ex) {
            System.out.println("erro al crear sentencia sql");
        }
    }
    
    public String registrar(Libro libro){
        String sentencia = "INSERT INTO libro VALUES(null , "+" '"+libro.getIsbn()+"' , '" + libro.getTitulo()+"', '"+libro.getAutor()+"' , '"+libro.getEditorial()+"' , '"+libro.getEdicion()+"')  ";
        try {
            int no = statement.executeUpdate(sentencia);
            if (no == 1) {
                return "exito";
            }else{
                return "error";
            }
        } catch (SQLException ex) {
            return "error sql";
        }
        
    }
    public Libro getLibro(String isbn){
        String sql="lelect * from libro where isbn="+isbn+";";
        try {
            resulSet=statement.executeQuery(sql);
            if (resulSet.next()){
            Libro libro=new Libro();
            libro.setIsbn(resulSet.getString("isbn"));
            libro.setAutor(resulSet.getString("autor"));
            libro.setEdicion(resulSet.getString("edicion"));
            libro.setEditorial(resulSet.getString("edicion"));
            libro.setTitulo(resulSet.getString("edicion"));
            return libro;
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
            
        }
        return null;
    }
    
}
