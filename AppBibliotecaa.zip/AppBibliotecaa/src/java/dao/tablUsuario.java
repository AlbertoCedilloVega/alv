
package dao;


public class tablUsuario {
    
}
