
package dao;

public class tablaDomicilio {
    
}
