package prueba;

import java.io.*;
import java.sql.Time;
import javax.servlet.*;
import javax.servlet.http.*;

public class PropiedadesSession extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        HttpSession session = request.getSession(true);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head>"
                + "<title> HttpSeesion</title></head><body>");
        if (session.isNew()) {
            out.println("La sesión es nueva<br>");
        } else {
            out.println("La sesión ya se habia creado");
        }
        out.println("La sesión tiene el identificador: " + session.getId() + "<br>");
        out.println("Una sesión puede permanecer inactiva: " + session.getMaxInactiveInterval() + " segundos<br>");

        Time f = new Time(session.getLastAccessedTime());
        Time i = new Time(session.getCreationTime());

        

        out.println("La sesión fue creada: "+ i+ "<br>");

        out.println("Se accedió la sesión por última vez: " + f + "<br>");
        
        Time d = new Time(session.getLastAccessedTime() - session.getCreationTime());
        out.println("La session Tardo: "+ d+ " segundos<br>");
        out.println("</body></html>");
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }
}
