
package prueba;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ServletCookies extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Muestra y crea cookies</title>");
        out.println("</head>");
        out.println("<body bgcolor=\"white\">");
        out.println("<CENTER>");
        out.println("<h1>Creación de una nueva cookie</h1><br>");
        Cookie cookie;
//se crea el formulario
        out.print("<form action=\"ServletCookies\" method=GET>");
        out.print("<b>Nombre:</b>");
        out.println("<input type=text length=20 name=nombreCookie><br><br>");
        out.print("<b>Valor:</b>");
        out.println("<input type=text length=20 name=valorCookie><br>");
        out.println("<input type=submit value=Enviar></form>");
//se recuperan los valores del formulario
        String nombreCookie = request.getParameter("nombreCookie");
        String valorCookie = request.getParameter("valorCookie");
//se crea la nueva cookie
        if (nombreCookie != null && valorCookie != null) {
            cookie = new Cookie(nombreCookie, valorCookie);
            response.addCookie(cookie);
            out.println("<P>Se ha añadido la cookie " + nombreCookie);
            out.print(" con el valor " + valorCookie);
        }
        
        out.println("<h1>Muestra las cookies</h1>");
//se muestran las cookies existentes en la petición
        out.println("<TABLE BORDER=1>"
                + "<caption>cookies exitentes</caption>"
                + "<TR BGCOLOR=\"red\">"
                + " <TH>Nombre de la cookie</TH>"
                + " <TH>valor de la cookie</TH></TR>"
        );
        Cookie[] cookies = request.getCookies();
        for (int i = 0; i < cookies.length; i++) {
            cookie = cookies[i];
            out.println("<TR>"
                    + " <TD BGCOLOR=\"yellow\">" + cookie.getName() + "</TD>"
                    + " <TD BGCOLOR=\"yellow\">" + cookie.getValue() + "</TD></TR>"
            );
        }
        out.println("</TABLE>");
        out.println("</CENTER>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }

}
