/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author MALVAES
 */
@WebServlet(name = "prueba", urlPatterns = {"/prueba"})
public class prueba extends HttpServlet {

    ArrayList wcrdList;
    String warrtingMessage;
    ArrayList rnoderatedparameters;

    public void init(FilterConfig config) throws ServletException {
        try {
            String fileName = config.getInitParameter("productos.txt");
            // Leer el archivo que contiene las palahras para la moderaci6n
            InputStream is = config.getServletContext().getResourceAsStream(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            wcrdList = new ArrayList();
            while (true) {
                String word = reader.readLine();
                if (word == null) {
                    break;
                }
                wcrdList.add(word.toLowerCase());
            }
            // Cbtener el archivo
            reader.close();
            // Cbtener el archivo de advertencia. Si no se encuentra, ~ltilirar mn p'r clefectr,
            warrtingMessage = config.getInitParameter("warrtingMessage");
            if (warrtingMessage == null) {
                String warrtingMessage = "+++ Message restricted";
            }

        } catch (IOException ie) {
            ie.printStackTrace();
            throw new ServletException("Error reading moderate words. txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
