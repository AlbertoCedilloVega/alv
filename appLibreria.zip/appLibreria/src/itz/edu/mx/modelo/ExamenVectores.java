/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itz.edu.mx.modelo;

import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author Lenovo
 */
public class ExamenVectores {
    
    public static String vec[];
    public static String rfcvec[];
    
    public static void main(String[] args) {
        int opcion = 0;
        int opcion1 = 0;
        try {
            do {
                opcion = Integer.parseInt((JOptionPane.showInputDialog(" menu inical\n" + "1.- registrar usuario\n" + "2.- visualiza usuario\n"
                        + "3.-generar rfcs\n" + "4.-visualizar rfcs\n" + "5.-Salir\n")));
                switch (opcion) {
                    case 1:
                        int num = leerInt("Introdusca el numero de usuarios");
                        vec = new String[num];
                        for (int i = 0; i < num; i++) {
                            vec[i] = JOptionPane.showInputDialog("ingresa el usuario");
                        }
                        break;
                    case 2:
                        if (vec.length > 0) {
                            String salida = "los usuarios registrados son \n";
                            System.out.println("" + vec.length);
                            for (int i = 0; i < vec.length; i++) {
                                salida += vec[i] + "\n";
                            }
                            visualizar(salida);
                        } else {
                            visualizar("no hay datos");
                        }
                        break;
                    case 3:
                        rfcvec = new String[vec.length];
                        for (int i = 0; i < vec.length; i++) {
                            StringBuilder nombre = new StringBuilder(vec[i].toUpperCase());
                            StringBuilder app = new StringBuilder(nombre.substring(0, nombre.indexOf(" ")));
                            nombre.delete(0, nombre.indexOf(" ") + 1);
                            StringBuilder apm = new StringBuilder(nombre.substring(0, nombre.indexOf(" ")));
                            nombre.delete(0, nombre.indexOf(" ") + 1);
                            String nom = nombre.substring(0, nombre.indexOf(" "));
                            nombre.delete(0, nombre.indexOf(" ") + 1);
                            String nomm = nombre.toString();
                            String nommm = nomm.replaceAll("DE ", "");
                            StringBuilder fecha = new StringBuilder(nommm);
                            String dia = fecha.substring(0, fecha.indexOf(" "));
                            fecha.delete(0, fecha.indexOf(" ") + 1);
                            String mes = fecha.substring(0, fecha.indexOf(" "));
                            fecha.delete(0, fecha.indexOf(" "));
                            String alo = fecha.toString();
                            String rfc = app.substring(0, 1);
                            app.delete(0, 1);
                            for (int j = 0; j < app.length(); j++) {
                                String letra = app.substring(j, j + 1);
                                if (letra.equals("A") | letra.equals("E") | letra.equals("I") | letra.equals("O") | letra.equals("U")) {
                                    rfc = rfc + letra;
                                    j = app.length();
                                }
                            }
                            rfc += apm.substring(0, 1);
                            rfc += nom.substring(0, 1);
                            rfc += alo.substring(3, alo.length());
                            switch (mes) {
                                case "ENERO":
                                    rfc = rfc + "01";
                                    break;
                                case "FEBRERO":
                                    rfc = rfc + "02";
                                    break;
                                case "MARZO":
                                    rfc = rfc + "03";
                                    break;
                                case "ABRIL":
                                    rfc = rfc + "04";
                                    break;
                                case "MAYO":
                                    rfc = rfc + "05";
                                    break;
                                case "JUNIO":
                                    rfc = rfc + "06";
                                    break;
                                case "JULIO":
                                    rfc = rfc + "07";
                                    break;
                                case "AGOSTO":
                                    rfc = rfc + "08";
                                    break;
                                case "SEPTIEMBRE":
                                    rfc = rfc + "09";
                                    break;
                                case "OCTUBRE":
                                    rfc = rfc + "10";
                                    break;
                                case "NOVIEMBRE":
                                    rfc = rfc + "11";
                                    break;
                                case "DICIEMBRE":
                                    rfc = rfc + "12";
                                    break;
                            }
                            rfc += dia;
                            rfcvec[i] = rfc;
                        }
                        visualizar("RFC generados con exito");
                        break;
                    case 4:
                        if (rfcvec.length>0){
                        String salida1 = "los rfc de los usuarios son \n";
                        System.out.println("" + rfcvec.length);
                        for (int i = 0; i < rfcvec.length; i++) {
                            salida1 += rfcvec[i] + "\n";
                        }
                        visualizar(salida1);
                        }else{
                            visualizar("No se han generado los rfc");
                        }
                        break;
                    case 5:
                        System.exit(0);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Solo hay 5 opciones");
                    
                }
            } while (opcion <= 5 || opcion > 5);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public static String leer(String mensaje) {
        return showInputDialog(mensaje);
    }
    
    public static void visualizar(String salida) {
        showMessageDialog(null, salida);
    }
    
    public static char leerChar(String mensaje) {
        return leer(mensaje).toUpperCase().charAt(0);
    }
    
    public static boolean continuar(String mensaje) {
        //int respuesta=showConfirmDialog(null,'mensaje',null,.YES_NO_OPTION);
        return true;
    }
    
    public static int leerInt(String mensaje) {
        do {
            try {
                int b = Integer.parseInt(leer(mensaje));
                return b;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }
    
    public static void llenarVector(String cadena, int i) {
        vec[i] = cadena;
    }
}
