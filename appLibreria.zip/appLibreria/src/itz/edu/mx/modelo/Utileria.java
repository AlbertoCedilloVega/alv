/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itz.edu.mx.modelo;

import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.*;

/**
 *
 * @author Lenovo
 */
public class Utileria {

    public static void main(String[] args) {
        //String nombre=leer("digite su nombre");
        //String app=leer("Ingrese su apellido paterno");
        //String apm=leer("ingrese al apellido materno");
        //char sexo=leerChar("ingrese su genero masculino[M]/Femenino[F]");
//        visualizar(nombre);
//        visualizar(app);
//        visualizar(apm);
//con un bit representamos 256 numero dividos desde el -128 a 127
        //String genero=sexo=='M'?"Masculino":"Femenino";
        //byte edad = leerByte("Digite su edad");
        //System.out.println(mixMax("lixlavadelavadelaaavadelaav"));
        //String completo=nombre+" "+app+" "+apm+" de genero "+genero;
        //visualizar(completo);
        //visualizar(String.valueOf(edad));       

        int pan = 0;
        do {
            //visualizar(aB(leer("Ingrese los datos")));
            visualizar(Boolean.toString(esAmigo(leerInt("ingresa un numero"),leerInt(ICON_PROPERTY))));
            pan = (JOptionPane.showConfirmDialog(null, "desea agregar otro", "", JOptionPane.YES_NO_OPTION));
        } while (pan == YES_OPTION);
        //System.out.println(last2("h"));
    }

    public static String leer(String mensaje) {
        return showInputDialog(mensaje);
    }

    public static void visualizar(String salida) {
        showMessageDialog(null, salida);
    }

    public static char leerChar(String mensaje) {
        return leer(mensaje).toUpperCase().charAt(0);
    }

    public static boolean continuar(String mensaje) {
        //int respuesta=showConfirmDialog(null,'mensaje',null,.YES_NO_OPTION);
        return true;
    }

    public static double leerDouble(String mensaje) {
        do {
            try {
                double d = Double.parseDouble(leer(mensaje));
                return d;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }

    public static float leerFloat(String mensaje) {
        do {
            try {
                float f = Float.parseFloat(leer(mensaje));
                return f;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }

    public static long leerLong(String mensaje) {
        do {
            try {
                long l = Long.parseLong(leer(mensaje));
                return l;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }

    public static int leerInt(String mensaje) {
        do {
            try {
                int b = Integer.parseInt(leer(mensaje));
                return b;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }

    public static short leerShort(String mensaje) {
        do {
            try {
                short b = Short.parseShort(leer(mensaje));
                return b;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }

    public static byte leerByte(String mensaje) {
        do {
            try {
                byte b = Byte.parseByte(leer(mensaje));
                return b;
            } catch (Exception e) {
                visualizar("porfavor ingrese un numero entero valido");
            }
        } while (true);
//        return 0;
    }
//    public static byte leerByte(String mensaje){
//        String entrada=null;
//        //byte b=0;
//        boolean res=false;
//        do{
//            entrada=leer(mensaje);
//            res=sonDigitos(entrada);
//            if(!res)visualizar("ingrese un numero entero valido");  
//        }while(!res);
//        return Byte.parseByte(mensaje);
//    }
//    public static boolean sonDigitos(String cadena){
//        String cadenax=cadena.trim();//quitar los espacion en blanco del principio y el final
//        System.out.println(""+cadenax.length());
//        for (int i=0;i<=cadenax.length();i++){
//            if (!Character.isDigit(cadenax.charAt(i))){
//                return false;
//            }
//        }
//        return true;
//    }
/*
Dada una cadena, si la cadena "del" aparece comenzando en el índice 1, devuelva una cadena donde esa "del" se haya eliminado.
De lo contrario, devuelve la cadena sin cambios.
delDel ("adelbc") → "abc" 
delDel ("adelHello") → "aHello" 
delDel ("adedbc") → "adedbc"  
     */
    public String delDel(String str) {
        int indice = str.indexOf("del");//el indice donde comienza
        if (indice == 1) {
            StringBuilder sb = new StringBuilder(str);
            sb.delete(indice, 4);
            return sb.toString();
        } else {
            return str;
        }
    }

    //para borrar el ultimo del de la cadena
    public static String delDel1(String str) {
        int indice = str.lastIndexOf("del");//el indice donde comienza
        if (indice > 1) {
            StringBuilder sb = new StringBuilder(str);
            sb.delete(indice, indice + 4);
            return sb.toString();
        } else {
            return str;
        }
    }

    public static String delDelOptimizado(String str) {
        int indice = str.lastIndexOf("del");//el indice donde comienza
        //return indice == 1 ? new StringBuilder(str).delete(indice, indice + 4).toString() : str;
        return str.indexOf("del") == 1 ? str.replaceFirst("del", "") : str;//con la clase replace First de Strong forramos el rpimero

    }

    public static String delDelTodos(String str) {
        return str.indexOf("del") >= 0 ? str.replace("del", "") : str;//con la clase replacede String borramos todos
    }

    //cuenta las e
    //toCharArray para convertir la cadena en vector de caracteres
    public static boolean stringE(String str) {
        int ce = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == 'e') {
                ce++;

            }

        }
        return ce >= 1 && ce <= 3;
    }

    public static String endUp(String str) {
        if (str.length() > 3) {
            String ul = str.substring(str.length() - 3, str.length());
            int u3 = str.lastIndexOf(ul);
            str = str.substring(0, u3) + ul.toUpperCase();
            return str;
        } else {
            return str.toUpperCase();
        }

    }

    public static String endUpOp(String str) {
        StringBuilder sb = new StringBuilder(str).reverse();
        if (str.length() > 3) {
            return sb.replace(0, 3, sb.substring(0, 3).toUpperCase()).reverse().toString();
        } else {
            return str.toUpperCase();
        }
        //return new StringBuilder(str).delete(str.length()-3,str.length())+str.substring(str.length()-3,str.length()).toUpperCase();
        //return str.length()>3?str.substring(0,str.lastIndexOf(str.substring(str.length()-3,str.length())))+str.substring(str.length()-3,str.length()).toUpperCase():str.toUpperCase();       
    }

    /*
Devuelva verdadero si la cadena dada comienza con "mix", excepto que 'm' puede ser cualquier cosa, así que "pix", "9ix" ... todos cuentan.*/
    public static boolean mixMax(String str) {
        return str.indexOf("ix") == 1 ? true : false;

    }

    public static String rfc(String str) {
        StringBuilder cadena = new StringBuilder(str);
        StringBuilder frag = new StringBuilder(cadena.substring(0, cadena.indexOf(" ")));
        String rfc = frag.substring(0, 1);
        cadena = cadena.delete(0, cadena.indexOf(" ") + 1);
        frag = frag.delete(0, 1);
        for (int i = 0; i < frag.length(); i++) {
            String letra = frag.substring(i, i + 1);
            System.out.println("" + letra);
            if (letra.equals("a") | letra.equals("e") | letra.equals("i") | letra.equals("o") | letra.equals("u")) {
                rfc = rfc + letra;
                i = frag.length();
            }
        }
        String fra = cadena.substring(0, cadena.indexOf(" "));
        cadena = cadena.delete(0, cadena.indexOf(" ") + 1);
        rfc = rfc + fra.substring(0, 1);
        fra = cadena.substring(0, cadena.indexOf(" "));
        cadena = cadena.delete(0, cadena.indexOf(" ") + 1);
        rfc = rfc + fra.substring(0, 1);
        fra = cadena.substring(cadena.length() - 5, cadena.length());
        cadena = cadena.delete(cadena.length() - 4, cadena.length());
        rfc = rfc + fra.substring(3, 5);
        System.out.println("" + fra + " " + cadena);
//        fra = cadena.substring(0, cadena.indexOf(" "));
//        cadena = cadena.delete(0, cadena.indexOf(" ") + 1);
//        String fr = cadena.substring(0, cadena.length()-1);
//        switch (fr) {
//            case "enero":
//                rfc = rfc + "01";
//                break;
//            case "febrero":
//                rfc = rfc + "02";
//                break;ezpinoza trejo aurelio 05 mayo 1970
//            case "marzo":
//                rfc = rfc + "03";
//                break;
//            case "abril":
//                rfc = rfc + "04";
//                break;
//            case "mayo":
//                rfc = rfc + "05";
//                break;
//            case "junio":
//                rfc = rfc + "06";
//                break;
//            case "julio":
//                rfc = rfc + "07";
//                break;
//            case "agosto":
//                rfc = rfc+"08";
//                break;
//            case "septiembre":
//                rfc = rfc+"09";
//                break;
//            case "octubre":
//                rfc = rfc + "10";
//                break;
//            case "noviembre":
//                rfc = rfc + "11";
//                break;
//            case "diciembre":
//                rfc = rfc + "12";
//                break;
//        }
//        rfc = rfc + fra.substring(0, 2);

        return rfc;
    }

    public static String aB(String cadena) {
        System.out.println("" + cadena.length());
        String ent = cadena.toUpperCase();
        if (cadena.length() > 1) {
            String salida = "";
            char a = ent.charAt(0);
            char b = ent.charAt(1);
            return a == 'A' && b == 'B' ? salida = "" + a + "" + b : a == 'A' && b != 'B' ? salida = "" + a : a != 'A' && b == 'B' ? salida = "" + b : salida;

        } else {
            return cadena;
        }
    }

    public static String everyNth(String str, int n) {
        String r = "";
        for (int i = 0; i < str.length(); i += n) {
            r += str.charAt(i);
        }
        return r;
    }

    public static String stringTimes(String str, int n) {
        String r = "";
        for (int i = 0; i < n; i++) {
            r += str;
        }
        return r;
    }

    public static boolean doubleX(String str) {
        int r = str.indexOf("x");
        return r + 1 == str.length() ? false : str.charAt(r + 1) == 'x' ? true : false;
    }

    public static int last2(String str) {
        StringBuilder s = new StringBuilder(str);
        int contador = 0;
        if (s.length() > 2) {
            String c = s.substring(s.length() - 2, s.length());
            s.delete(s.length() - 1, s.length());
            for (int i = 0; i < str.length() - 2; i++) {
                if (c.equals(s.substring(i, i + 2))) {
                    contador++;
                }
                System.out.println("" + s.substring(i, i + 2));

            }
        }
        return contador;
    }

    public static boolean esPrimo(int n) {
        if (n < 1) {
            return false;
        } else {
            for (int i = 2; i <= n / 2; i++) {
                if (n % i == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean esPerfecto(int n) {
        int suma = 1;
        if (n < 1) 
            return false;
        else
            for (int i = 2; i <= n / 2; i++) 
                if (n % i == 0) 
                    suma += i;
        return suma==n;

    }
    public static boolean esAmigo(int n, int m){
        int res1 = 0, res2 = 0;
        for (int i = 1; i <= m/2; i++) 
            if ((m % i) == 0 | i == 1) 
                res1 += i;
        for (int i = 1; i <= n/2; i++) 
            if ((n % i) == 0 | i == 1) 
                res2 += i;
        return (res1 == n) && (res2 == m);
        
    }
    //tarea de un vectory calcular cuantos son imapres, la suma de los imares,cuantos son primos,la suma de los primos,cuantos son perfectos,
    //el promedio de lso numeros perfectos, el mayor de todos,meno de todos ,promedio de todos, factorial de cada uno,

}
