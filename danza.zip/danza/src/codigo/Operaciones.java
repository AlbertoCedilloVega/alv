/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
/**
 *
 * @author Mauricio
 */
public class Operaciones {
    static Connection con=null;
    static Statement sente;
    static ResultSet resu;  
    
public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print(e);
        }
}
/*
public static void insertaDisciplina(Disciplina d){
Operaciones.conecta();
String insert1="Insert into disciplina values(null,'"+d.getDisciplina()+"');";
try {
          sente.executeUpdate(insert1);
          JOptionPane.showMessageDialog(null, "Datos Insertados Exitosamente");
        } catch (Exception e) {
          JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al insertar disciplina\n"+e);     
        }   
}

/*

public static void insertaRamaDisciplina(Disciplina d, String claveDis){
Operaciones.conecta();
String insert1="Insert into rama_disciplina values(null,'"+d.getRama()+",'"+d.getPrecio()+",'"+d.getDescripcion()+",'"+claveDis+"');";
try {
          sente.executeUpdate(insert1);
          JOptionPane.showMessageDialog(null, "Datos Insertados Exitosamente");
        } catch (Exception e) {
          JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al insertar disciplina\n"+e);     
        }   
}

public static void insertaAula(Aula a){
Operaciones.conecta();
String insert1="Insert into aula values(null,"+a.getCapacidad()+");";
try {
          sente.executeUpdate(insert1);
          JOptionPane.showMessageDialog(null, "Datos Insertados Exitosamente");
        } catch (Exception e) {
          JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al insertar aula\n"+e);     
        } 
    
    
}

public static void insertaHorario(String hora,String grado, String dia, String cveRama){
Operaciones.conecta();
String insert1="Insert into Horario values(null,'"+hora+"','"+grado+",'"+dia+"'"+cveRama+"');";
try {
          sente.executeUpdate(insert1);
          JOptionPane.showMessageDialog(null, "Datos Insertados Exitosamente");
        } catch (Exception e) {
          JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al insertar aula\n"+e);     
        } 
    
    
}


*/
}