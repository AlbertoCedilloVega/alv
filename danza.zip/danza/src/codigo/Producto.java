package codigo;
public class Producto {

 private String nombrepro;
 private String codbarpro;
 private String tallapro;
 private String fecha;
 private String prevedorpro;
 private String prevedorpro1;
 private String telefonoprov;
 private String representanteprov;
 private String marca;
 private int cantidad;
 private int max;
 private int min;
 public Producto(String nombrepro,String marca,String codbarpro,String tallapro,String provedropro,String provedropro1,String telefonoprov,String representanteprv,int cantidad,int max,int min,String fecha){
     this.nombrepro=nombrepro;
     this.marca=marca;
     this.codbarpro=codbarpro;
     this.tallapro=tallapro;
     this.prevedorpro=provedropro;
     this.prevedorpro1=provedropro1;
     this.telefonoprov=telefonoprov;
     this.representanteprov=representanteprv;
     this.cantidad=cantidad;
     this.max=max;
     this.min=min;
     this.fecha=fecha;
     
 }

 
    public String getNombrepro() {
        return nombrepro;
    }

    public void setNombrepro(String nombrepro) {
        this.nombrepro = nombrepro;
    }

    public String getCodbarpro() {
        return codbarpro;
    }

    public void setCodbarpro(String codbarpro) {
        this.codbarpro = codbarpro;
    }

    public String getTallapro() {
        return tallapro;
    }

    public void setTallapro(String tallapro) {
        this.tallapro = tallapro;
    }   
     public String getPrevedorpro() {
        return prevedorpro;
    }

    public void setPrevedorpro(String prevedorpro) {
        this.prevedorpro = prevedorpro;
    }

    public String getPrevedorpro1() {
        return prevedorpro1;
    }

    public void setPrevedorpro1(String prevedorpro1) {
        this.prevedorpro1 = prevedorpro1;
    }
    
    public String getTelefonoprov() {
        return telefonoprov;
    }

    public void setTelefonoprov(String telefonoprov) {
        this.telefonoprov = telefonoprov;
    }

    public String getRepresentanteprov() {
        return representanteprov;
    }

    public void setRepresentanteprov(String representanteprov) {
        this.representanteprov = representanteprov;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    

  

}
