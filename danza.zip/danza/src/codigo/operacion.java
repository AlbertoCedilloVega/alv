package codigo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class operacion {
    DefaultTableModel model;
    static Connection con=null;
    static Statement sente;
    static ResultSet resu; 
    private String correo;
    public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print("no funciono");
        }
    }
        public static void iniciarTransaccion(){
        String inicio="start transaction;";
        try {
          sente.executeUpdate(inicio);      
        } catch (Exception e) {
          System.out.print(e);
        }
    }
    public static void cancelarTransaccion(){
        String cancela="rollback;";
         try {
          sente.executeUpdate(cancela);      
        } catch (Exception e) {
          System.out.print(e);
        }
    }
    public static void consumarTransaccion(){
        String consuma="commit;";
         try {
          sente.executeUpdate(consuma);      
        } catch (Exception e) {
          System.out.print(e);
        }
    }
    public static void isertprodu1(Producto x){
        operacion.conecta();
        int llave,llave1,llave2,llave3;
        PreparedStatement pst;
        PreparedStatement pst1;
        PreparedStatement pst2;
        PreparedStatement pst3;
        PreparedStatement pst4;
        
        try{
        con.setAutoCommit(false);
        String insertapro=" insert into producto(nom_producto,marca_producto) values ('"+x.getNombrepro()+"','"+x.getMarca()+"');";
        pst=con.prepareStatement(insertapro,PreparedStatement.RETURN_GENERATED_KEYS);
        if (pst.executeUpdate()==1){
            ResultSet idsGenerados= pst.getGeneratedKeys();
               if (idsGenerados!=null && idsGenerados.next()){
                   llave=idsGenerados.getInt(1);
//                   String insertprov="insert into proveedor(nombre_prov,telefono_prov,representante_prov) values ('"+x.getPrevedorpro()+"','"+x.getTelefonoprov()+"','"+x.getRepresentanteprov()+"');";
//                   pst1=con.prepareStatement(insertprov,PreparedStatement.RETURN_GENERATED_KEYS);
//                   if(pst1.executeUpdate()==1){
//                       ResultSet idsGenerados1=pst1.getGeneratedKeys();
//                       if (idsGenerados1!=null && idsGenerados1.next()){
//                           llave1=idsGenerados1.getInt(1);
                           String insertTalla="insert into talla (talla_talla) values ('"+x.getTallapro()+"');";
                           pst2=con.prepareStatement(insertTalla,PreparedStatement.RETURN_GENERATED_KEYS);
                           if (pst2.executeUpdate()==1){
                               ResultSet idsGenerados2=pst2.getGeneratedKeys();
                               if (idsGenerados2!=null && idsGenerados2.next()){
                                   llave2=idsGenerados2.getInt(1);
                                   String qq="select id_prov from proveedor where nombre_prov='"+x.getPrevedorpro1()+"';";
                                   resu=sente.executeQuery(qq);
                                   while(resu.next()){
                                       String llave11=resu.getString("id_prov");
                                   String insertKar="insert into kardex (cant_kardex,min_kardex,max_kardex,producto_cve_producto,proveedor_id_prov,talla_cve_talla) values ("
                                           +x.getCantidad()+","+x.getMin()+","+x.getMax()+","+llave+","+llave11+","+llave2+");";
                                   pst3=con.prepareStatement(insertKar, PreparedStatement.RETURN_GENERATED_KEYS);
                                   if(pst3.executeUpdate()==1){
                                       ResultSet ides=pst3.getGeneratedKeys();
                                       if (ides!=null && ides.next()){
                                           llave3=ides.getInt(1);
                                           String q="insert into precio_producto (precio_precio_pro,compra_precio_pro,fecha_precio_pro,kardex_cve_kardex) values ('"+0.0+"','"+0.0+"','"+x.getFecha()+"','"+llave3+ "');";
                                           pst3=con.prepareStatement(q);
                                           pst3.executeUpdate();
                                           con.commit();
                                       }
                                   }
                                   }
                               }
                           }else{
                               con.rollback();
                           }
                       }
//                   }else{
//                       con.rollback();
//                   }
//               }
                              
        }else{
            con.rollback();
        }
        } catch (Exception e) {
        System.err.println("error asssss" +e);
        }finally{
            try {
                if(con!=null){con.close();}
                if (sente!=null){sente.close();}
            } catch (Exception e) {
                System.err.println("error rrrrrrr" +e);
            }
        }    
    }
    public static void insertprodu(Producto x){
        operacion.conecta();
        int llave,llave1,llave2,llave3;
        PreparedStatement pst;
        PreparedStatement pst1;
        PreparedStatement pst2;
        PreparedStatement pst3;
        PreparedStatement pst4;
        
        try{
        con.setAutoCommit(false);
        String insertapro=" insert into producto(nom_producto,marca_producto) values ('"+x.getNombrepro()+"','"+x.getMarca()+"');";
        pst=con.prepareStatement(insertapro,PreparedStatement.RETURN_GENERATED_KEYS);
        if (pst.executeUpdate()==1){
            ResultSet idsGenerados= pst.getGeneratedKeys();
               if (idsGenerados!=null && idsGenerados.next()){
                   llave=idsGenerados.getInt(1);
                   String insertprov="insert into proveedor(nombre_prov,telefono_prov,representante_prov) values ('"+x.getPrevedorpro()+"','"+x.getTelefonoprov()+"','"+x.getRepresentanteprov()+"');";
                   pst1=con.prepareStatement(insertprov,PreparedStatement.RETURN_GENERATED_KEYS);
                   if(pst1.executeUpdate()==1){
                       ResultSet idsGenerados1=pst1.getGeneratedKeys();
                       if (idsGenerados1!=null && idsGenerados1.next()){
                           llave1=idsGenerados1.getInt(1);
                           String insertTalla="insert into talla (talla_talla) values ('"+x.getTallapro()+"');";
                           pst2=con.prepareStatement(insertTalla,PreparedStatement.RETURN_GENERATED_KEYS);
                           if (pst2.executeUpdate()==1){
                               ResultSet idsGenerados2=pst2.getGeneratedKeys();
                               if (idsGenerados2!=null && idsGenerados2.next()){
                                   llave2=idsGenerados2.getInt(1);
                                   String insertKar="insert into kardex (cant_kardex,min_kardex,max_kardex,producto_cve_producto,proveedor_id_prov,talla_cve_talla) values ("
                                           +x.getCantidad()+","+x.getMin()+","+x.getMax()+","+llave+","+llave1+","+llave2+");";
                                   pst3=con.prepareStatement(insertKar, PreparedStatement.RETURN_GENERATED_KEYS);
                                   if(pst3.executeUpdate()==1){
                                       ResultSet ides=pst3.getGeneratedKeys();
                                       if (ides!=null && ides.next()){
                                           llave3=ides.getInt(1);
                                           String q="insert into precio_producto (precio_precio_pro,compra_precio_pro,fecha_precio_pro,kardex_cve_kardex) values ('"+0.0+"','"+0.0+"','"+x.getFecha()+"','"+llave3+ "');";
                                           pst3=con.prepareStatement(q);
                                           pst3.executeUpdate();
                                           con.commit();
                                       }
                                   }
                               }
                           }else{
                               con.rollback();
                           }
                       }
                   }else{
                       con.rollback();
                   }
               }
                              
        }else{
            con.rollback();
        }
        } catch (Exception e) {
        System.err.println("error" +e);
        }finally{
            try {
                if(con!=null){con.close();}
                if (sente!=null){sente.close();}
            } catch (Exception e) {
                System.err.println("error de registro en operacion" +e);
            }
        }
    }
    public  void buscarpro(String tex){
    try{
        operacion.conecta();
        String [] titulos={"nombre","cantidad","talla","proveedor"};
        String filtro=""+tex+"_%;";
        String quer="select nom_producto,cant_kardex,talla_talla,nombre_prov from kardex join producto join talla join proveedor on kardex.producto_cve_producto=producto.cve_producto and kardex.talla_cve_talla=talla.cve_talla and kardex.proveedor_id_prov=proveedor.id_prov where nombre_prov like "+'"'+filtro+'"';
        System.out.println(quer);
        model= new DefaultTableModel(null,titulos);
        sente=con.prepareStatement(quer);
        ResultSet rs=sente.executeQuery(quer);
        String []fila=new String[5];
        while(rs.next()){
            fila[0]=rs.getString("nom_producto");
            fila[1]=rs.getString("cant_kardex");
            fila[2]=rs.getString("talla_talla");
            fila[3]=rs.getString("nombre_prov");
            model.addRow(fila);
        }
        
    }catch(Exception e){
        
    }
}
    
}
