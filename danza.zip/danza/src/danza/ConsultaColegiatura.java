
package danza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class ConsultaColegiatura extends javax.swing.JFrame {
    static Statement sente;
    static ResultSet resu;
    static ResultSet resu1;
    static Connection con= null;
    //DefaultTableModel modelo = new DefaultTableModel();

    public ConsultaColegiatura() {
        initComponents();
        mostrarDatos();
    }
    
    public static void conecta(){
        String bd = "mydb";
        String url = "jdbc:mysql://localhost/"+bd;
        String user = "root";
        String pass = "root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente = con.createStatement();
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error "+e);
        }
    }
    
    void mostrarDatos(){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Clave Alumno");
        modelo.addColumn("Nombre");
        modelo.addColumn("Tel. Tutor");
        modelo.addColumn("Monto");
        modelo.addColumn("Status");
        modelo.addColumn("Fecha");
        tabla.setModel(modelo);
        
        String sql2 = "select id_alumno, persona.nom_persona,tel_tutor,colegiatura.monto_colegiatura,colegiatura.status_colegiatura, renglon_colegiatura.fecha_renglon_cole from alumno "
                + "join persona join tutor join colegiatura join renglon_colegiatura "
                + "on persona.cve_persona=alumno.Persona_cve_persona "
                + "and tutor.cve_tutor=alumno.Tutor_cve_tutor "
                + "and colegiatura.alumno_cve_alumno=alumno.cve_alumno "
                + "and renglon_colegiatura.Colegiatura_cve_colegiatura=colegiatura.cve_colegiatura;";    
        String[] datos = new String[7];
        // System.out.println(sql2);
        try {
            conecta();
            resu=sente.executeQuery(sql2);
             while (resu.next()) {
                datos[0]=resu.getString(1);
                datos[1]=resu.getString(2);
                datos[2]=resu.getString(3);
                datos[3]=resu.getString(4);
                datos[4]=resu.getString(5);
                datos[5]=resu.getString(6);
                modelo.addRow(datos);
            }
            tabla.setModel(modelo);
        } catch (SQLException ex) {
            System.out.println("error: "+ex);
        }
    }
    
    void mostrarTabla(){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Clave Alumno");
        modelo.addColumn("Nombre");
        modelo.addColumn("Tel. Tutor");
        modelo.addColumn("Monto");
        modelo.addColumn("Status");
        modelo.addColumn("Fecha");
        tabla.setModel(modelo);
        
        if (pagos.isSelected()== true){
            String sql2 = "select id_alumno, persona.nom_persona,tel_tutor,colegiatura.monto_colegiatura,colegiatura.status_colegiatura, renglon_colegiatura.fecha_renglon_cole from alumno "
                + "join persona join tutor join colegiatura join renglon_colegiatura "
                + "on persona.cve_persona=alumno.Persona_cve_persona "
                + "and tutor.cve_tutor=alumno.Tutor_cve_tutor "
                + "and colegiatura.alumno_cve_alumno=alumno.cve_alumno "
                + "and renglon_colegiatura.Colegiatura_cve_colegiatura=colegiatura.cve_colegiatura "
                + "where colegiatura.status_colegiatura = 'Adeudo';"; 
            String[] datos = new String[7];
            try {
                conecta();
                resu=sente.executeQuery(sql2);
                while (resu.next()) {
                    datos[0]=resu.getString(1);
                    datos[1]=resu.getString(2);
                    datos[2]=resu.getString(3);
                    datos[3]=resu.getString(4);
                    datos[4]=resu.getString(5);
                    datos[5]=resu.getString(6);
                    modelo.addRow(datos);
                }
                tabla.setModel(modelo);
            } catch (SQLException ex) {
                System.out.println("error: "+ex);
            }
        }else{
            mostrarDatos();
        }
    }
    void buscar(){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Clave Alumno");
        modelo.addColumn("Nombre");
        modelo.addColumn("Tel. Tutor");
        modelo.addColumn("Monto");
        modelo.addColumn("Status");
        modelo.addColumn("Fecha");
        tabla.setModel(modelo);
        
        if (pagos.isSelected()== true){
            String sql2 = "select id_alumno, persona.nom_persona,tel_tutor,colegiatura.monto_colegiatura,colegiatura.status_colegiatura, renglon_colegiatura.fecha_renglon_cole from alumno "
                + "join persona join tutor join colegiatura join renglon_colegiatura "
                + "on persona.cve_persona=alumno.Persona_cve_persona "
                + "and tutor.cve_tutor=alumno.Tutor_cve_tutor "
                + "and colegiatura.alumno_cve_alumno=alumno.cve_alumno "
                + "and renglon_colegiatura.Colegiatura_cve_colegiatura=colegiatura.cve_colegiatura "
                + "where id_alumno = '"+clave.getText()+"' and colegiatura.status_colegiatura = 'Adeudo';"; 
            String[] datos = new String[7];
            try {
                conecta();
                resu=sente.executeQuery(sql2);
                while (resu.next()) {
                    datos[0]=resu.getString(1);
                    datos[1]=resu.getString(2);
                    datos[2]=resu.getString(3);
                    datos[3]=resu.getString(4);
                    datos[4]=resu.getString(5);
                    datos[5]=resu.getString(6);
                    modelo.addRow(datos);
                }
                tabla.setModel(modelo);
            } catch (SQLException ex) {
                System.out.println("error: "+ex);
            }
        }else{
            if (pagos.isSelected()==false) {
                String sql2 = "select id_alumno, persona.nom_persona,tel_tutor,colegiatura.monto_colegiatura,colegiatura.status_colegiatura, renglon_colegiatura.fecha_renglon_cole from alumno "
                    + "join persona join tutor join colegiatura join renglon_colegiatura "
                    + "on persona.cve_persona=alumno.Persona_cve_persona "
                    + "and tutor.cve_tutor=alumno.Tutor_cve_tutor "
                    + "and colegiatura.alumno_cve_alumno=alumno.cve_alumno "
                    + "and renglon_colegiatura.Colegiatura_cve_colegiatura=colegiatura.cve_colegiatura "
                    + "where id_alumno = '"+clave.getText()+"';"; 
                String[] datos = new String[7];
                try {
                    conecta();
                    resu=sente.executeQuery(sql2);
                    while (resu.next()) {
                        datos[0]=resu.getString(1);
                        datos[1]=resu.getString(2);
                        datos[2]=resu.getString(3);
                        datos[3]=resu.getString(4);
                        datos[4]=resu.getString(5);
                        datos[5]=resu.getString(6);
                        modelo.addRow(datos);
                    }
                    tabla.setModel(modelo);
                } catch (SQLException ex) {
                    System.out.println("error: "+ex);
                }
            }else{
                mostrarDatos();
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        buscar = new javax.swing.JButton();
        clave = new javax.swing.JTextField();
        pagos = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        tituloFondo = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        fondoCuerpo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Consulta de datos de Colegiaturas");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 310, -1));

        buscar.setBackground(new java.awt.Color(0, 102, 153));
        buscar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        buscar.setText("Buscar");
        buscar.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        getContentPane().add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 80, 120, 30));

        clave.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                claveActionPerformed(evt);
            }
        });
        getContentPane().add(clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 200, 30));

        pagos.setBackground(new java.awt.Color(0, 0, 0));
        pagos.setForeground(new java.awt.Color(255, 255, 255));
        pagos.setText("Pendientes de Pago");
        pagos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagosActionPerformed(evt);
            }
        });
        getContentPane().add(pagos, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, -1, -1));

        tabla.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 530, 250));

        jLabel18.setBackground(new java.awt.Color(255, 255, 255));
        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Clave del Alumno :");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 160, 30));

        tituloFondo.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tituloFondo.setOpaque(true);
        getContentPane().add(tituloFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 530, 150));

        jButton2.setBackground(new java.awt.Color(0, 102, 153));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Realizar Pago");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 440, 170, 40));

        jButton1.setBackground(new java.awt.Color(253, 82, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, 130, 40));

        fondoCuerpo.setBackground(new java.awt.Color(153, 0, 51));
        fondoCuerpo.setOpaque(true);
        getContentPane().add(fondoCuerpo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        buscar();
    }//GEN-LAST:event_buscarActionPerformed

    private void claveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_claveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_claveActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Principal vp=new Principal();
        vp.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
 
    }//GEN-LAST:event_tablaMouseClicked

    private void pagosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagosActionPerformed
       // modelo = new DefaultTableModel();
        //tabla.setModel(modelo);
        mostrarTabla();
    }//GEN-LAST:event_pagosActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int fila = tabla.getSelectedRow();
        String cve_alu,res="";
        cve_alu = tabla.getValueAt(fila,0).toString();
        String id = "select cve_alumno from alumno where id_alumno='"+cve_alu+"';";
        
        try {
            resu=sente.executeQuery(id);
            while(resu.next()){
                res=resu.getString("cve_alumno");
            }
            String act_cole="update colegiatura set status_colegiatura='Pagado' where colegiatura.alumno_cve_alumno="+res+";";
            sente.executeUpdate(act_cole);
            
        } catch (Exception e) {
            System.out.println("danza.ConsultaColegiatura.jButton2ActionPerformed()"+e);
        }
        mostrarDatos();
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaColegiatura().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buscar;
    private javax.swing.JTextField clave;
    private javax.swing.JLabel fondoCuerpo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton pagos;
    private javax.swing.JTable tabla;
    private javax.swing.JLabel tituloFondo;
    // End of variables declaration//GEN-END:variables
}
