/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class ConsultaEmpleados extends javax.swing.JFrame {
    static Statement sente;
    static ResultSet resu;
    static Connection con= null;
    /**
     * Creates new form ConsultaMaestros
     */
    public ConsultaEmpleados() {
        initComponents();
        mostrarTabla();
    }
    
    public static void conecta(){
        String bd = "mydb";
        String url = "jdbc:mysql://localhost/"+bd;
        String user = "root";
        String pass = "root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente = con.createStatement();
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error "+e);
        }
    }
    
    void mostrarTabla(){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Clave");
        modelo.addColumn("Nombre");
        modelo.addColumn("Genero");
        modelo.addColumn("Telefono");
        modelo.addColumn("E-mail");
        modelo.addColumn("Tipo");
        tabla.setModel(modelo);
        
        if (tipo.getSelectedItem().toString().equals("Seleccione...")) {
            String query="select cve_empleado, concat(persona.nom_persona,' ',ap_persona,' ',am_persona)as nombre,"
                    + "sexo_persona, tel_empleado, correo_empleado,tipo_empleado "
                    + "from empleado join persona on persona.cve_persona=empleado.Persona_cve_persona; ";
            String[] datos = new String[6];
            try {
                conecta();
                resu=sente.executeQuery(query);
                while (resu.next()) {
                    datos[0]=resu.getString("cve_empleado");
                    datos[1]=resu.getString("nombre");
                    datos[2]=resu.getString("sexo_persona");
                    datos[3]=resu.getString("tel_empleado");
                    datos[4]=resu.getString("correo_empleado");
                    datos[5]=resu.getString("tipo_empleado");
                    modelo.addRow(datos);
                }
                tabla.setModel(modelo);
            } catch (SQLException e) {
                System.out.println("error: "+e);
            }
        }else{
            if (tipo.getSelectedItem().toString().equals("Maestro")) {
                String query="select cve_empleado, concat(persona.nom_persona,' ',ap_persona,' ',am_persona)as nombre,"
                    + "sexo_persona, tel_empleado, correo_empleado,tipo_empleado "
                    + "from empleado join persona on persona.cve_persona=empleado.Persona_cve_persona "
                    + "where tipo_empleado='Maestro';";
                String[] datos = new String[6];
                try {
                    conecta();
                    resu=sente.executeQuery(query);
                    while (resu.next()) {
                        datos[0]=resu.getString("cve_empleado");
                        datos[1]=resu.getString("nombre");
                        datos[2]=resu.getString("sexo_persona");
                        datos[3]=resu.getString("tel_empleado");
                        datos[4]=resu.getString("correo_empleado");
                        datos[5]=resu.getString("tipo_empleado");
                        modelo.addRow(datos);
                    }
                    tabla.setModel(modelo);
                } catch (SQLException e) {
                    System.out.println("error: "+e);
                }
            }else{
                if (tipo.getSelectedItem().toString().equals("Auxiliar")) {
                    String query="select cve_empleado, concat(persona.nom_persona,' ',ap_persona,' ',am_persona)as nombre,"
                        + "sexo_persona, tel_empleado, correo_empleado,tipo_empleado "
                        + "from empleado join persona on persona.cve_persona=empleado.Persona_cve_persona "
                        + "where tipo_empleado='Auxiliar';";
                    String[] datos = new String[6];
                    try {
                        conecta();
                        resu=sente.executeQuery(query);
                        while (resu.next()) {
                            datos[0]=resu.getString("cve_empleado");
                            datos[1]=resu.getString("nombre");
                            datos[2]=resu.getString("sexo_persona");
                            datos[3]=resu.getString("tel_empleado");
                            datos[4]=resu.getString("correo_empleado");
                            datos[5]=resu.getString("tipo_empleado");
                            modelo.addRow(datos);
                        }
                        tabla.setModel(modelo);
                    } catch (SQLException e) {
                        System.out.println("error: "+e);
                    }
                }
            }
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        tipo = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        tituloFondo = new javax.swing.JLabel();
        fondoCuerpo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Consulta de Maestros");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 220, -1));

        jButton1.setBackground(new java.awt.Color(0, 102, 153));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Regresar al inicio");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 170, 30));

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 570, 220));

        tipo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione...", "Maestro", "Auxiliar" }));
        tipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipoActionPerformed(evt);
            }
        });
        getContentPane().add(tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 190, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tipo de epleado ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        tituloFondo.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo.setOpaque(true);
        getContentPane().add(tituloFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 110));

        fondoCuerpo.setBackground(new java.awt.Color(153, 0, 51));
        fondoCuerpo.setOpaque(true);
        getContentPane().add(fondoCuerpo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 590, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Principal p=new Principal();
        p.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipoActionPerformed
         mostrarTabla();
    }//GEN-LAST:event_tipoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel fondoCuerpo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    private javax.swing.JComboBox<String> tipo;
    private javax.swing.JLabel tituloFondo;
    // End of variables declaration//GEN-END:variables
}
