/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author KAMBALAM
 */
public class ConsultaPedidos extends javax.swing.JFrame {
    DefaultTableModel model=new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row,int colum){
            return false;
        }
    };
    DefaultTableModel model1=new DefaultTableModel(){
                    @Override
                    public boolean isCellEditable(int row,int colum){
                        return false;
                    }
                };
private int co =0;
    private double com=0.0,ven=0.0;
    static Connection con=null;
    static Statement sente;
    static ResultSet resu;
    /**
     * Creates new form ConsultaPedidos
     */
    public ConsultaPedidos() {
        initComponents();
        llen();
    }
    public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print(e);
        }
    }
    public void llen(){
        String q="Select folio_pedido from pedido where status_pedido='pendiente'";
        try {
            conecta();
            resu=sente.executeQuery(q);
            String [] titu=new String[] {"Folio pedido","Cv Producto","Nombre","Talla","Precio","Cantidad"};
            model.setColumnIdentifiers(titu);
            int i=0;
            String [] fila=new String [9];
            while(resu.next()){
                i=i+1;
            }
            System.out.println(i);
             String []vec=new String[i];
            int j=0;
            resu=sente.executeQuery(q);
            while(resu.next()){
                vec[j]=resu.getString("folio_pedido");
                j++;
            }
            for(int h=0;vec.length>h;h++){
                
                try {
                    String q1="select costo_renped,sum(cant_renped)from renglon_ped where pedido_folio_pedido='"+vec[h]+"' group by kardex_cve_kardex;";
                    String q2="select pp,ka,nom_producto,talla_talla,fe,tot,st,co,ca from producto join talla join kardex join (select pedido_folio_pedido as pp, kardex_cve_kardex as ka,fecha_pedido as fe,total_pedido as tot,status_pedido as st,sum(cant_renped) as ca,costo_renped as co from renglon_ped join pedido on pedido.folio_pedido=renglon_ped.pedido_folio_pedido where folio_pedido='"+vec[h]+"' group by kardex_cve_kardex)as x on kardex.talla_cve_talla=talla.cve_talla and kardex.producto_cve_producto=producto.cve_producto and kardex.cve_kardex=x.ka;";
                    resu=sente.executeQuery(q2);
                    while(resu.next()){
                        fila[0]=resu.getString("pp");
                    fila[1]=resu.getString("ka");
                    fila[2]=resu.getString("nom_producto");
                    fila[3]=resu.getString("talla_talla");
//                    fechap.setText(resu.getString("fe"));
//                    totalp.setText(resu.getString("tot"));
//                    stap.setText(resu.getString("st"));
                    fila[4]=resu.getString("co");
                    fila[5]=resu.getString("ca");
                    model.addRow(fila);
                }
                jTable1.setModel(model);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null,"error interno"+e);
                }
                System.out.println(vec[h]);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error al consegir todos lo pedidos"+ e,"error",JOptionPane.ERROR_MESSAGE);
        }
        
    }
    public void consulta(String c){
        model=new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int colum){
                return false;
            }
        };
        
        String q="select ka,nom_producto,talla_talla,fe,tot,st,co,ca from producto join talla join kardex join (select kardex_cve_kardex as ka,fecha_pedido as fe,total_pedido as tot,status_pedido as st,cant_renped as ca,costo_renped as co from renglon_ped join pedido on pedido.folio_pedido=renglon_ped.pedido_folio_pedido where folio_pedido='"+c+"')as x on kardex.talla_cve_talla=talla.cve_talla and kardex.producto_cve_producto=producto.cve_producto and kardex.cve_kardex=x.ka;";
        try {
            conecta();
            String [] titu=new String[] {"Cv Producto","Nombre","Talla","Precio","Cantidad"};
            model.setColumnIdentifiers(titu);
            resu=sente.executeQuery(q);
            String [] fila=new String [9];
            if (resu.next()){
                fila[0]=resu.getString("ka");
                fila[1]=resu.getString("nom_producto");
                fila[2]=resu.getString("talla_talla");
                fechap.setText(resu.getString("fe"));
                totalp.setText(resu.getString("tot"));
                stap.setText(resu.getString("st"));
                fila[3]=resu.getString("co");
                fila[4]=resu.getString("ca");
                model.addRow(fila);
                while(resu.next()){
                    fila[0]=resu.getString("ka");
                    fila[1]=resu.getString("nom_producto");
                    fila[2]=resu.getString("talla_talla");
                    fechap.setText(resu.getString("fe"));
                    totalp.setText(resu.getString("tot"));
                    stap.setText(resu.getString("st"));
                    fila[3]=resu.getString("co");
                    fila[4]=resu.getString("ca");
                    model.addRow(fila);
                }
                jTable1.setModel(model);
            }else{
                JOptionPane.showMessageDialog(null,"El pedido no existe","Atencion",JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al buscar el pedido"+e,"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    public void verifica(){
        String c;
        try {
            conecta();
            int filas=model.getRowCount();
            for(int i=0;i<filas;i++){
                c=jTable1.getValueAt(i, 0).toString();
                String q="select cant_kardex,precio_precio_pro from precio_producto join (select max(num_precio_pro) as m from precio_producto group by kardex_cve_kardex)as x join producto join kardex join talla join proveedor on precio_producto.num_precio_pro=x.m and kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex and kardex.talla_cve_talla=talla.cve_talla and kardex.proveedor_id_prov=proveedor.id_prov where precio_producto.num_precio_pro=x.m and cve_kardex='"+c+"';";
                String [] titu=new String[] {"Cantidad","Precio"};
                model1.setColumnIdentifiers(titu);
                String [] fila1=new String [3];
                resu=sente.executeQuery(q);
                while(resu.next()){
                    fila1[0]=resu.getString("cant_kardex");
                    fila1[1]=resu.getString("precio_precio_pro");
                    model1.addRow(fila1);
                }
            }
            jTable2.setModel(model1);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al verificar"+ e,"Error",JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jSeparator3 = new javax.swing.JSeparator();
        folio = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Consultar = new javax.swing.JButton();
        fechap = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jCheckBox2 = new javax.swing.JCheckBox();
        totalp = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jCheckBox3 = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        stap = new javax.swing.JTextField();
        buscar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        tituloFondo = new javax.swing.JLabel();
        fondoCuerpo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cantidad", "Precio"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 180, 160, 210));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cv Producto", "Nombre", "Talla", "Precio", "Cantidad"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 460, 210));

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, 10, 50));

        folio.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        getContentPane().add(folio, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 130, 30));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cambiar Status");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 100, 130, 30));

        Consultar.setBackground(new java.awt.Color(0, 204, 0));
        Consultar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Consultar.setText("Verificar");
        Consultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultarActionPerformed(evt);
            }
        });
        getContentPane().add(Consultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 130, -1, 30));
        getContentPane().add(fechap, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 130, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Folio");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 60, 30));

        jCheckBox2.setBackground(new java.awt.Color(51, 51, 51));
        jCheckBox2.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBox2.setText("Cancelado");
        getContentPane().add(jCheckBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 130, -1, -1));
        getContentPane().add(totalp, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, 110, 30));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Total del pedido");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 60, 120, 30));

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 10, 50));

        jCheckBox3.setBackground(new java.awt.Color(51, 51, 51));
        jCheckBox3.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBox3.setText("Surtido");
        getContentPane().add(jCheckBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Actual");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 50, 30));
        getContentPane().add(stap, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 120, 30));

        buscar.setBackground(new java.awt.Color(0, 204, 0));
        buscar.setText("Buscar");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        getContentPane().add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 90, 30));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Fecha del pedido");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 120, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Status");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 50, 30));

        jButton1.setText("Cambiar");
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 130, 80, 30));

        cancelar.setBackground(new java.awt.Color(204, 0, 0));
        cancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 130, 80, 30));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 630, 10));

        tituloFondo.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo.setOpaque(true);
        getContentPane().add(tituloFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 170));

        fondoCuerpo.setBackground(new java.awt.Color(153, 0, 51));
        fondoCuerpo.setOpaque(true);
        getContentPane().add(fondoCuerpo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 650, 240));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        // TODO add your handling code here:
        String c=folio.getText();
        consulta(c);
        model1=new DefaultTableModel();
        String [] titu=new String[] {"Cantidad","Precio"};
        model1.setColumnIdentifiers(titu);
        jTable2.setModel(model1);
    }//GEN-LAST:event_buscarActionPerformed

    private void ConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultarActionPerformed
        // TODO add your handling code here:
        verifica();
    }//GEN-LAST:event_ConsultarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        Principal vp=new Principal();
        vp.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaPedidos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Consultar;
    private javax.swing.JButton buscar;
    private javax.swing.JButton cancelar;
    private javax.swing.JTextField fechap;
    private javax.swing.JTextField folio;
    private javax.swing.JLabel fondoCuerpo;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField stap;
    private javax.swing.JLabel tituloFondo;
    private javax.swing.JTextField totalp;
    // End of variables declaration//GEN-END:variables
}
