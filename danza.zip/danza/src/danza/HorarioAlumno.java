package danza;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class HorarioAlumno extends javax.swing.JFrame {
 static Connection con=null;
 static Statement sente;
 static ResultSet resu;
 DefaultTableModel modelo2;
 DefaultTableModel modelo1;
 DefaultTableModel modeloI; 
 private String datosT;
 private String datosA;
 private String idA;
 
public HorarioAlumno(String datosT,String idA,String datosA) {
        initComponents();
        modelo2=(DefaultTableModel) horario2.getModel();
        modelo1=(DefaultTableModel) horario1.getModel();
        modeloI=(DefaultTableModel) horarioI.getModel();
        this.datosT=datosT;
        this.datosA=datosA;
        this.idA=idA;
        alumno.setText(idA+" "+datosA);
        
        jScrollPane1.setVisible(false);
        String bd ="mydb";    
        String url="jdbc:mysql://localhost/"+bd;
        String user="root";
        String pass="root";
            try {
                con = DriverManager.getConnection(url,user,pass);
                sente=con.createStatement();
                System.out.print("Conectado");
            } catch (Exception e) {
                System.out.print(e);
            }
        //---------------------------------------------------------------------    
        disciplinas.removeAllItems();
        try{
            String  aulasQ="select * from disciplina where status_dis='activo'";  
            resu=sente.executeQuery(aulasQ);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al conseguir dis\n"+e); 
        }
        try{
            while(resu.next()){
            disciplinas.addItem(resu.getString("nom_dis"));
            }
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al asignar dis\n"+e); 
        }
        //---------------------------------------------------------------------
        
        //---------------------------------------------------------------------
        String alu=null;
        
        String q="select max(cve_alumno) from alumno";
         try{
            resu=sente.executeQuery(q);
            
        if(resu.next()){
            alu=(resu.getString("max(cve_alumno)"));
            } 
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al asignar dis\n"+e); 
        }
         
        String buscaDisciplina="select * from disciplina join empleado join persona join aula join horariomaestro join horarioalumno join alumno "
            + "on disciplina.cve_dis=horariomaestro.disciplina_cve_dis and empleado.cve_empleado=horariomaestro.empleado_cve_empleado "
            + "and aula.cve_aula=horariomaestro.Aula_cve_aula and persona.cve_persona = empleado.Persona_cve_persona and horariomaestro.num_horario"
                + "= horarioalumno.horario_num_horario and horarioalumno.alumno_cve_alumno=alumno.cve_alumno WHERE "
                + "YEAR(horariomaestro.fecha_ini)=YEAR(curdate()) and alumno.cve_alumno="+
                alu;
         try{ 
            resu=sente.executeQuery(buscaDisciplina);
            while(resu.next()){
                 modelo2.addRow(new String[]{"true",resu.getString("num_horario"),resu.getString("nom_dis"),
                 (resu.getString("nom_persona")+" "+resu.getString("ap_persona")),
                  resu.getString("hora_horario"),resu.getString("nombre_aula"),
                  resu.getString("grado_horario"),resu.getString("dia_horario")}); 
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al llenar la tabla2\n"+e); 
        }
    }

    private HorarioAlumno() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        horarioI = new javax.swing.JTable();
        agregarDis = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        disciplinas = new javax.swing.JComboBox<>();
        buscar = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        horario2 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        horario1 = new javax.swing.JTable();
        eliminar = new javax.swing.JButton();
        alumno = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        horarioI.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Disciplina", "Dia", "Hora", "Grado", "Maestro", "Aula"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(horarioI);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 630, 330));

        agregarDis.setBackground(new java.awt.Color(0, 102, 153));
        agregarDis.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        agregarDis.setText("AGREGAR DISCIPLINA ->");
        agregarDis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarDisActionPerformed(evt);
            }
        });
        jPanel1.add(agregarDis, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 460, -1, 40));

        cancelar.setBackground(new java.awt.Color(253, 82, 0));
        cancelar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cancelar.setText("CANCELAR");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        jPanel1.add(cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 110, 40));

        guardar.setBackground(new java.awt.Color(0, 102, 153));
        guardar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        guardar.setText("GUARDAR E IMPRIMIR HORARIO");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        jPanel1.add(guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 460, -1, 40));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REGISTRO DE HORARIO DEL ALUMNO");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel1.setOpaque(true);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 1250, 40));

        jLabel3.setBackground(new java.awt.Color(51, 51, 51));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Horario");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel3.setOpaque(true);
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 70, 120, 40));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Disciplina");
        jLabel9.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 250, 40));

        disciplinas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(disciplinas, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 220, 40));

        buscar.setBackground(new java.awt.Color(0, 102, 153));
        buscar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        buscar.setText("BUSCAR");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        jPanel1.add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 70, 130, 40));

        horario2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "CVE HOR", "DISCIPLINA", "MAESTRO", "HORA", "AULA", "GRADO", "DIA"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        horario2.setRowHeight(20);
        jScrollPane3.setViewportView(horario2);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, 640, 320));

        horario1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "CVE HOR", "DISCIPLINA", "MAESTRO", "HORA", "AULA", "GRADO", "DIA"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        horario1.setRowHeight(20);
        jScrollPane4.setViewportView(horario1);

        jPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 620, 320));

        eliminar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        eliminar.setText("ELIMINAR");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        jPanel1.add(eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 460, 120, 40));

        alumno.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        alumno.setForeground(new java.awt.Color(255, 255, 255));
        alumno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        alumno.setText("Alumno");
        alumno.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jPanel1.add(alumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 70, 490, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1320, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
    this.setVisible(false);
    Principal p= new Principal();
    p.setVisible(true);
    }//GEN-LAST:event_cancelarActionPerformed
    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        String cveAlumno="",numHorario="",guardarHorario="",cve_pago="";
        String alu=null;
        
        String q="select max(cve_alumno) from alumno";
        int cc=modelo2.getRowCount();
         try{
            resu=sente.executeQuery(q);
            if(resu.next()){
            alu=(resu.getString("max(cve_alumno)"));
            } 
            String con="select cve_ch,precio_ch from costohorario where cantidad_ch='"+cc+"'";
            resu=sente.executeQuery(con);
        if(resu.next()){
            cve_pago=(resu.getString("cve_ch"));
            } 
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al asignar dis\n"+e); 
        }
        cveAlumno=alu;
        for(int i=0;i<modelo2.getRowCount();i++){
        numHorario=modelo2.getValueAt(i, 1).toString();
        if(modelo2.getValueAt(i, 0).toString().equals("false")){
        guardarHorario="insert into horarioalumno values (null,"+numHorario+","+cveAlumno+","+cve_pago+")";    
            try {
              sente.execute(guardarHorario);
              
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        }
        
        jScrollPane1.setVisible(true);
        String dis[]=new String[horario2.getRowCount()];
        
        for (int i = 0; i < horario2.getRowCount(); i++) {
            dis[i]=((String) modelo2.getValueAt(i, 2))+" "+((String)modelo2.getValueAt(i, 4));
            
            modeloI.addRow(new Object[]{
                
                modelo2.getValueAt(i, 2),modelo2.getValueAt(i, 7),
                modelo2.getValueAt(i, 4),modelo2.getValueAt(i, 6),
                 modelo2.getValueAt(i, 3),modelo2.getValueAt(i, 5)});
        }
        try {
            MessageFormat mensajeTitulo= new MessageFormat("Horario Escolar \n ID: "+idA+" Alumno : "+
                    datosA);
            
            MessageFormat mensajePie= new MessageFormat("Ciclo escolar : 2018 - 2019");
            horarioI.print(JTable.PrintMode.FIT_WIDTH,mensajeTitulo,mensajePie);
        } catch (Exception e) {
        
        }
        
        jScrollPane1.setVisible(false);
        this.setVisible(false);
        PagoInscripcion pi= new PagoInscripcion(datosT,datosA,dis);
        pi.setVisible(true);
    }//GEN-LAST:event_guardarActionPerformed
    private void agregarDisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarDisActionPerformed
        int fila = horario1.getSelectedRow();
        boolean bandera=false;
		if (fila != -1) {
			int nColumns = horario1.getColumnCount();
			Object[] filaSeleccionada = new Object[nColumns];
			for (int i = 0; i < filaSeleccionada.length; ++i){
                            filaSeleccionada[i] = modelo1.getValueAt(fila, i);
                        }
                        for(int i=0;i<modelo2.getRowCount();i++){
                             if(
                                (modelo2.getValueAt(i, 1).equals(filaSeleccionada[1].toString()))&&
                                (modelo2.getValueAt(i, 2).equals(filaSeleccionada[2].toString()))&&    
                                (modelo2.getValueAt(i, 3).equals(filaSeleccionada[3].toString()))&&
                                (modelo2.getValueAt(i, 4).equals(filaSeleccionada[4].toString()))&&
                                (modelo2.getValueAt(i, 5).equals(filaSeleccionada[5].toString()))&&
                                (modelo2.getValueAt(i, 6).equals(filaSeleccionada[6].toString()))&&
                                (modelo2.getValueAt(i, 7).equals(filaSeleccionada[7].toString()))     
                               ){
                                JOptionPane.showMessageDialog(null, "Usted ya ha seleccionado esa materia");  
                                bandera=true;
                                } 
                        }                   
                        if (bandera==false){
                        modelo2.addRow(filaSeleccionada);
                        }
		}else{
			        JOptionPane.showMessageDialog(this, "No hay registro seleccionado");
                }
    }//GEN-LAST:event_agregarDisActionPerformed
    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        for (int i = 0; i < horario1.getRowCount(); i++) {
            modelo1.removeRow(i);
            i-=1;
        }
        
        String buscaDisciplina="select * from disciplina join empleado join persona join aula join horariomaestro "
            + "on disciplina.cve_dis=horariomaestro.disciplina_cve_dis and empleado.cve_empleado=horariomaestro.empleado_cve_empleado "
            + "and aula.cve_aula=horariomaestro.Aula_cve_aula and persona.cve_persona = empleado.Persona_cve_persona "
            + "where YEAR(horariomaestro.fecha_ini)=YEAR(curdate()) and disciplina.nom_dis='"+disciplinas.getSelectedItem().toString()+"'";
            
         try{ 
            resu=sente.executeQuery(buscaDisciplina);
            while(resu.next()){
                 modelo1.addRow(new String[]{"false",resu.getString("num_horario"),resu.getString("nom_dis"),resu.getString("nom_persona")+" "+resu.getString("ap_persona"),
                 resu.getString("hora_horario"),resu.getString("nombre_aula"),
                 resu.getString("grado_horario"),resu.getString("dia_horario")}); 
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al llenar la tabla1\n"+e); 
        }
    }//GEN-LAST:event_buscarActionPerformed
    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        int fila = horario1.getSelectedRow();
        if (fila != -1) {
            modelo2.removeRow(horario2.getSelectedRow());
        }else{
	    JOptionPane.showMessageDialog(this, "No hay registro seleccionado");
        }
    }//GEN-LAST:event_eliminarActionPerformed
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HorarioAlumno().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton agregarDis;
    private javax.swing.JLabel alumno;
    private javax.swing.JButton buscar;
    private javax.swing.JButton cancelar;
    private javax.swing.JComboBox<String> disciplinas;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton guardar;
    private javax.swing.JTable horario1;
    private javax.swing.JTable horario2;
    private javax.swing.JTable horarioI;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}