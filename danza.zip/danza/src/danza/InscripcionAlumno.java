package danza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class InscripcionAlumno extends javax.swing.JFrame {
    static ResultSet resu;
    static Statement sente;
    static Connection con;
    String nomTutor="",apTutor="",amTutor="";
    boolean datosTutor=false;
    String id="";

    public InscripcionAlumno(String nomTutor,String apTutor,String amTutor,Boolean datosTutor) {
        initComponents();
        datosT.setText(nomTutor+" \n "+apTutor+" "+amTutor);
        this.datosTutor=datosTutor;
    }

    public void conecta(){
        String bd="mydb";
        String url="jdbc:mysql://localhost/"+bd;
        String user="root";
        String password="root"
                + "";
        try {
            con=DriverManager.getConnection(url,user,password);
            sente=con.createStatement();
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error, no conectó "+e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        nombreAlu = new javax.swing.JTextField();
        apAlu = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        sexoAlu = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        inscribirAlumno = new javax.swing.JButton();
        amAlu = new javax.swing.JTextField();
        dia = new javax.swing.JComboBox<>();
        mes = new javax.swing.JComboBox<>();
        año = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        datosT = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jDesktopPane1.setBackground(new java.awt.Color(153, 0, 51));
        jDesktopPane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Inscripcion Alumno");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel1.setOpaque(true);
        jDesktopPane1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 850, 40));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre:");
        jDesktopPane1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, 60, 20));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Apellido P.");
        jDesktopPane1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 70, 20));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Apellido M.");
        jDesktopPane1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 70, 20));
        jDesktopPane1.add(nombreAlu, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 350, 30));
        jDesktopPane1.add(apAlu, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 350, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Sexo:");
        jDesktopPane1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, -1, -1));

        sexoAlu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F" }));
        jDesktopPane1.add(sexoAlu, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 340, 70, 30));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Nombre del tutor:");
        jDesktopPane1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, -1, 30));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Fecha Nac:");
        jDesktopPane1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, -1, -1));

        inscribirAlumno.setBackground(new java.awt.Color(102, 102, 255));
        inscribirAlumno.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        inscribirAlumno.setText("Inscribir");
        inscribirAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inscribirAlumnoActionPerformed(evt);
            }
        });
        jDesktopPane1.add(inscribirAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 470, 150, 40));
        jDesktopPane1.add(amAlu, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 350, 30));

        dia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jDesktopPane1.add(dia, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, 60, -1));

        mes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        jDesktopPane1.add(mes, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 60, -1));

        año.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014" }));
        jDesktopPane1.add(año, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 280, 90, -1));

        jButton2.setText("Cancelar");
        jDesktopPane1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 100, 40));

        datosT.setForeground(new java.awt.Color(255, 255, 255));
        jDesktopPane1.add(datosT, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 110, 190, 20));

        getContentPane().add(jDesktopPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void inscribirAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inscribirAlumnoActionPerformed
        String llave1 = null;
        
        String tutor = null;
        if(datosTutor==true){
        String fecha=dia.getSelectedItem().toString()+"/"+mes.getSelectedItem().toString()+"/"+año.getSelectedItem().toString();
        PreparedStatement pst,pst2;
        try {
            conecta();
            String q="select max(cve_tutor) from tutor";
            resu=sente.executeQuery(q);
            
            id=nombreAlu.getText().substring(0)+apAlu.getText().substring(0)+amAlu.getText().substring(0)+
                    dia.getSelectedItem().toString()+mes.getSelectedItem().toString()+año.getSelectedItem().toString();
            
            if(resu.next()){
            tutor=(resu.getString("max(cve_tutor)"));
            }
            
            String query="insert into persona(nom_persona,ap_persona,am_persona,sexo_persona,fechanac_persona)"
            + " values('"+nombreAlu.getText().toUpperCase()+"','"+apAlu.getText().toUpperCase()+"','"+amAlu.getText().toUpperCase()+"','"+
            sexoAlu.getSelectedItem().toString()+"','"+fecha+"')";
            JOptionPane.showMessageDialog(null,"query: "+query);
            pst=con.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            
            String q2="select max(cve_persona) from persona";
            resu=sente.executeQuery(q2);
            
            
            if(resu.next()){
            llave1=(resu.getString("max(cve_persona)"));
            }         
                   
                    
                    String query1="Insert into alumno (id_alumno,Tutor_cve_tutor,Persona_cve_persona)values('"+id+"',"+tutor+","+llave1+ ");";
                    sente.execute(query1);
                    
                    JOptionPane.showMessageDialog(null,"Se a registrado con exito","Exito",JOptionPane.INFORMATION_MESSAGE);
                   
                
            
            String datosA=nombreAlu.getText()+" "+apAlu.getText()+" "+amAlu.getText();
                        HorarioAlumno ha=new HorarioAlumno(datosT.getText(),id,datosA);
                        ha.setVisible(true);
                        this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error"+e);
        }
        }else{
            JOptionPane.showMessageDialog(null,"Datos del tutor o del alumo vacios");
        }
    }//GEN-LAST:event_inscribirAlumnoActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InscripcionAlumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InscripcionAlumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InscripcionAlumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InscripcionAlumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InscripcionAlumno().setVisible(true);
            }
        });
    }
    
    
    public InscripcionAlumno() {
        initComponents();
        datosT.setText(nomTutor+" \n "+apTutor+" "+amTutor);
       }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amAlu;
    private javax.swing.JTextField apAlu;
    private javax.swing.JComboBox<String> año;
    private javax.swing.JLabel datosT;
    private javax.swing.JComboBox<String> dia;
    private javax.swing.JButton inscribirAlumno;
    private javax.swing.JButton jButton2;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JComboBox<String> mes;
    private javax.swing.JTextField nombreAlu;
    private javax.swing.JComboBox<String> sexoAlu;
    // End of variables declaration//GEN-END:variables
}
