package danza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class InscripcionTutor extends javax.swing.JFrame {
    static ResultSet resu;
    static Statement sente;
    static Connection con;
 
    public InscripcionTutor() {
        initComponents();
        String iS="";
        for(int i=1950;i<=2000;i++){
        año.addItem(iS+i);
        }
    }
    
    public void conecta(){
        String bd="mydb";
        String url="jdbc:mysql://localhost/"+bd;
        String user="root";
        String password="root";
        try {
            con=DriverManager.getConnection(url,user,password);
            sente=con.createStatement();
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error, no conectó "+e);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        nombreTutor = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        apTutor = new javax.swing.JTextField();
        telefonoTutor = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        coloniaTutor = new javax.swing.JTextField();
        sexoTutor = new javax.swing.JComboBox<>();
        ciudadTutor = new javax.swing.JTextField();
        guardarTutor = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        ncalleTutor = new javax.swing.JTextField();
        estadoTutor = new javax.swing.JTextField();
        calleTutor = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        ladaTutor = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        amTutor = new javax.swing.JTextField();
        correoTutor = new javax.swing.JTextField();
        dia = new javax.swing.JComboBox<>();
        mes = new javax.swing.JComboBox<>();
        año = new javax.swing.JComboBox<>();
        orie = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 0, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" Registro de Tutor");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel1.setOpaque(true);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 670, 40));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("               Dirección de Tutor");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 500, 330, 20));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Fecha Nac:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Sexo:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 450, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 60, 20));

        nombreTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreTutorActionPerformed(evt);
            }
        });
        jPanel1.add(nombreTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 350, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Apellido P.");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 70, 20));
        jPanel1.add(apTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, 350, 30));
        jPanel1.add(telefonoTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 330, 200, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Teléfono:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 70, 20));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Estado:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 550, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Lada:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, -1, -1));

        coloniaTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coloniaTutorActionPerformed(evt);
            }
        });
        jPanel1.add(coloniaTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 590, 160, 30));

        sexoTutor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F" }));
        sexoTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sexoTutorActionPerformed(evt);
            }
        });
        jPanel1.add(sexoTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 450, 70, 30));

        ciudadTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ciudadTutorActionPerformed(evt);
            }
        });
        jPanel1.add(ciudadTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 540, 170, 30));

        guardarTutor.setBackground(new java.awt.Color(102, 102, 255));
        guardarTutor.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        guardarTutor.setText("Guardar");
        guardarTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarTutorActionPerformed(evt);
            }
        });
        jPanel1.add(guardarTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 780, 130, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("               Datos del Tutor");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, 330, 20));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Ciudad:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 540, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Colonia:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 600, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Orientación:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 650, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Calle:");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 700, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Número calle:");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 600, -1, -1));

        ncalleTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ncalleTutorActionPerformed(evt);
            }
        });
        jPanel1.add(ncalleTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 590, 170, 30));

        estadoTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estadoTutorActionPerformed(evt);
            }
        });
        jPanel1.add(estadoTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 540, 160, 30));

        calleTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calleTutorActionPerformed(evt);
            }
        });
        jPanel1.add(calleTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 690, 470, 30));

        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 770, -1, -1));

        ladaTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ladaTutorActionPerformed(evt);
            }
        });
        jPanel1.add(ladaTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 330, 70, 30));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Apellido M.");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 70, 20));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Correo:");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 70, 20));
        jPanel1.add(amTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 230, 350, 30));
        jPanel1.add(correoTutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, 350, 30));

        dia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jPanel1.add(dia, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 60, -1));

        mes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        jPanel1.add(mes, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 400, 60, -1));

        jPanel1.add(año, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 400, 90, -1));

        orie.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NORTE", "SUR", "ESTE", "OESTE" }));
        jPanel1.add(orie, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 640, 160, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 822, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nombreTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreTutorActionPerformed

    private void coloniaTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_coloniaTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_coloniaTutorActionPerformed

    private void ciudadTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ciudadTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ciudadTutorActionPerformed

    private void guardarTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarTutorActionPerformed
      String fecha = dia.getSelectedItem().toString()+"/"+mes.getSelectedItem().toString()+"/"+año.getSelectedItem().toString();
      
        if((!nombreTutor.getText().equals(""))&& (!apTutor.getText().equals(""))
               && (!amTutor.getText().equals("")) && (!correoTutor.getText().equals("")) && (!telefonoTutor.getText().equals(""))
               && (!estadoTutor.getText().equals(""))&& (!coloniaTutor.getText().equals(""))&& (!ciudadTutor.getText().equals(""))
               && (!ladaTutor.getText().equals(""))&& (!ncalleTutor.getText().equals(""))
               && (!calleTutor.getText().equals(""))){
           int llave1,llave2;
           
        PreparedStatement pst,pst2,pst3;
        try {
            conecta();
            //con.setAutoCommit(false);
            //sente.execute("start transaction");
            String query="insert into persona(nom_persona,ap_persona,am_persona,sexo_persona,fechanac_persona)"
                + " values('"+nombreTutor.getText()+"','"+apTutor.getText()+"','"+amTutor.getText()+"','"+
                sexoTutor.getSelectedItem().toString()+"','"+fecha+"')";
            
            JOptionPane.showMessageDialog(null,"query: "+query);
            pst=con.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            if(pst.executeUpdate()==1){
                ResultSet ides=pst.getGeneratedKeys();
                if(ides!=null && ides.next()){
                    llave1=ides.getInt(1);
                    JOptionPane.showMessageDialog(null,"Llave1: "+llave1);
                    String queryDireccion="insert into direccion(calle_direccion,num_direccion,orientacion_direccion,"
                    + "estado_direccion,muni_direccion,localidad_direccion,lada_direccion)values('"+calleTutor
                    .getText().toUpperCase()+"','"+ncalleTutor.getText()+"','"+orie.getSelectedItem().toString()+"','"+estadoTutor.getText().toUpperCase()+
                    "','"+ciudadTutor.getText().toUpperCase()+"','"+coloniaTutor.getText().toUpperCase()+"','"+ladaTutor.getText()+"')";
                    JOptionPane.showMessageDialog(null,"queryDir: "+queryDireccion);
                     pst2=con.prepareStatement(queryDireccion,PreparedStatement.RETURN_GENERATED_KEYS);
                     
                     if(pst2.executeUpdate()==1){
                         ResultSet ides2=pst2.getGeneratedKeys();
                         if(ides2!=null && ides2.next()){
                             llave2=ides2.getInt(1);
                             JOptionPane.showMessageDialog(null,"Llave2: "+llave2);
                             String queryTutor="insert into tutor(correo_tutor,tel_tutor,Persona_cve_persona,Diereccion_cve_direccion) values('"+correoTutor.getText()+
                                     "','"+telefonoTutor.getText()+"',"+llave1+","+llave2+")";
                             JOptionPane.showMessageDialog(null,"Query: "+queryTutor);
                             pst3=con.prepareStatement(queryTutor);
                             
                             if(pst3.executeUpdate()==1){
                                 //con.commit();
                                 JOptionPane.showMessageDialog(null,"Ingresado con exito");
                                 InscripcionAlumno ia=new InscripcionAlumno(nombreTutor.getText(),apTutor.getText(),amTutor.getText(),true);
                                 ia.setVisible(true);
                                 this.setVisible(false);
                             }else{
                                 //con.rollback();
                             }
                         }
                     }else{
                         //con.rollback();
                     }
                }else{
                    //con.rollback();
                }
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
       }else{
           JOptionPane.showMessageDialog(null,"Es necesario llenar todos los campos");
       }
        
        
    }//GEN-LAST:event_guardarTutorActionPerformed

    private void sexoTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sexoTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sexoTutorActionPerformed

    private void ncalleTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ncalleTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ncalleTutorActionPerformed

    private void estadoTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estadoTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estadoTutorActionPerformed

    private void calleTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calleTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calleTutorActionPerformed

    private void ladaTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ladaTutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ladaTutorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Principal ia=new Principal();
                                 ia.setVisible(true);
                                 this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InscripcionTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InscripcionTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InscripcionTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InscripcionTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InscripcionTutor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amTutor;
    private javax.swing.JTextField apTutor;
    private javax.swing.JComboBox<String> año;
    private javax.swing.JTextField calleTutor;
    private javax.swing.JTextField ciudadTutor;
    private javax.swing.JTextField coloniaTutor;
    private javax.swing.JTextField correoTutor;
    private javax.swing.JComboBox<String> dia;
    private javax.swing.JTextField estadoTutor;
    private javax.swing.JButton guardarTutor;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField ladaTutor;
    private javax.swing.JComboBox<String> mes;
    private javax.swing.JTextField ncalleTutor;
    private javax.swing.JTextField nombreTutor;
    private javax.swing.JComboBox<String> orie;
    private javax.swing.JComboBox<String> sexoTutor;
    private javax.swing.JTextField telefonoTutor;
    // End of variables declaration//GEN-END:variables
}
