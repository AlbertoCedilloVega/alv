/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
/**
 *
 * @author KAMBALAM
 */
public class PagoColegiatura extends javax.swing.JFrame {
    static Statement sente;
    static ResultSet resu;
    static Connection con= null;
    static String t=null,A=null;
    /**
     * Creates new form PagoColegiatura
     */
    public PagoColegiatura() {
        initComponents();
        fecha.setText(fecha());
        cubrir.setText(fecha());
    }
    
    public static void conecta(){
        String bd = "mydb";
        String url = "jdbc:mysql://localhost/"+bd;
        String user = "root";
        String pass = "root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente = con.createStatement();
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error "+e);
        }
    }
    public static String fecha(){
        Date now=new Date(System.currentTimeMillis());
        SimpleDateFormat date=new SimpleDateFormat("YYYY-MM-dd");
        return date.format(now);
    }
    
    public void buscarA(String c){
        
        String c1=null,c2=null;
        try {
            conecta();
            String query = "select cve_alumno,alumno.Tutor_cve_tutor,persona.nom_persona,persona.ap_persona,persona.am_persona from alumno join persona on alumno.Persona_cve_persona=persona.cve_persona where alumno.id_alumno='"+c+"';";
            ResultSet re= sente.executeQuery(query);
           // resu = sente.executeQuery(query);
            //System.out.println(resu.getString("persona.nom_persona"));
            if(re.next()){
                t=re.getString("alumno.Tutor_cve_tutor");
                A=re.getString("cve_alumno");
                String nom=(re.getString("persona.nom_persona")+" "+re.getString("persona.ap_persona")+" "+re.getString("persona.am_persona"));
                nombre1.setText(nom);
                //System.out.println(re.getString("persona.nom_persona"));
            }
            String costo = "select costohorario_cve_ch from horarioalumno where cve_alumno='"+A+"' order by num_hor_maestro_alum desc limit 1;";
            System.out.println("danza.PagoColegiatura.buscarA()"+costo);
            ResultSet re1 = sente.executeQuery(costo);
            if(re1.next()){
                c1=re1.getString("costohorario_cve_ch");
                System.out.println(c1);
            }
            String costo2 ="select preciocol_ch from costohorario where cve_ch='"+c1+"'";
            System.out.println("danza.PagoColegiatura.buscarA()"+costo2);
            ResultSet re2 = sente.executeQuery(costo2);
            if(re2.next()){
                c2=re2.getString("preciocol_ch");
                System.out.println(c2);
                monto.setText(c2);
            }
        } catch (Exception e) {
        }
    }
    public void regP(){
        int key1,key2;
        PreparedStatement psp1;
        PreparedStatement psp2;
        PreparedStatement psp3;
        
        try {
            
            con.setAutoCommit(false);
            System.out.println( t  +A);
            String q2 = "insert into pago(fecha_pago,monto_pago,tutor_cve_tutor) values('"+fecha.getText()+"','"+monto.getText()+"','"+t+"');";
            psp1=con.prepareStatement(q2,PreparedStatement.RETURN_GENERATED_KEYS);
            if (psp1.executeUpdate()==1) {
                System.out.println("uno");
                ResultSet idGenerado= psp1.getGeneratedKeys();
                if (idGenerado!=null && idGenerado.next()) {
                    key1=idGenerado.getInt(1);
                    String q3 = "insert into colegiatura(monto_colegiatura,status_colegiatura,alumno_cve_alumno)values('"+monto.getText()+"','"+status.getSelectedItem().toString()+"','"+A+"');";
                    psp2=con.prepareStatement(q3,PreparedStatement.RETURN_GENERATED_KEYS);
                    if (psp2.executeUpdate()==1) {
                        System.out.println("uno");
                        ResultSet idGenerado1= psp2.getGeneratedKeys();
                        if (idGenerado1!=null && idGenerado1.next()) {
                            key2=idGenerado1.getInt(1);
                            String q4 = "insert into renglon_colegiatura(fecha_renglon_cole,Colegiatura_cve_colegiatura,pago_folio_pago) values('"+cubrir.getText()+"','"+key2+"','"+key1+"');";
                            psp3=con.prepareStatement(q4,PreparedStatement.RETURN_GENERATED_KEYS);
                            psp3.executeUpdate();
                            con.commit();
                            JOptionPane.showMessageDialog(null, "Registrado");
                        }
                    }
                }
                
            }
            
        } catch (SQLException e) {
            System.out.println("Error: " + e);
        }
    } 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        monto = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        nombre1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        botonProp = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        fecha = new javax.swing.JTextField();
        folio = new javax.swing.JTextField();
        clave = new javax.swing.JTextField();
        cubrir = new javax.swing.JTextField();
        status = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tituloFondo = new javax.swing.JLabel();
        tituloFondo1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("                                PAGO COLEGIATURA");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 510, 40));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Folio");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 50, 30));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("FECHA:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 70, 30));

        monto.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        monto.setText(" ");
        monto.setEnabled(false);
        monto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                montoActionPerformed(evt);
            }
        });
        monto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                montoKeyTyped(evt);
            }
        });
        getContentPane().add(monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 270, 80, -1));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Alumno:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 80, 30));

        nombre1.setEditable(false);
        nombre1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nombre1.setText(" ");
        nombre1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombre1ActionPerformed(evt);
            }
        });
        getContentPane().add(nombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 160, 30));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("$");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, -1, 30));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Fecha a Cubrir:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 120, 30));

        botonProp.setBackground(new java.awt.Color(0, 102, 153));
        botonProp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        botonProp.setText("Realizar Pago");
        botonProp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPropActionPerformed(evt);
            }
        });
        getContentPane().add(botonProp, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 330, 130, 40));

        jButton1.setBackground(new java.awt.Color(253, 82, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 130, 40));

        fecha.setEditable(false);
        fecha.setEnabled(false);
        getContentPane().add(fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 130, 30));
        getContentPane().add(folio, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, 90, 30));

        clave.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                claveActionPerformed(evt);
            }
        });
        clave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                claveKeyReleased(evt);
            }
        });
        getContentPane().add(clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 90, 30));
        getContentPane().add(cubrir, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 130, 30));

        status.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        status.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pagado", "Adeudo" }));
        getContentPane().add(status, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, 110, 30));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Cve. Alumno:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 120, 30));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("MONTO:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, 80, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Estatus: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 207, 70, 30));

        tituloFondo.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tituloFondo.setOpaque(true);
        getContentPane().add(tituloFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 510, 330));

        tituloFondo1.setBackground(new java.awt.Color(153, 0, 51));
        tituloFondo1.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo1.setOpaque(true);
        getContentPane().add(tituloFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void montoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_montoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_montoActionPerformed

    private void nombre1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombre1ActionPerformed

    private void botonPropActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPropActionPerformed
        regP();
        ConsultaColegiatura cc=new ConsultaColegiatura();
        cc.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_botonPropActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       Principal vp=new Principal();
        vp.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void claveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_claveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_claveActionPerformed

    private void claveKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_claveKeyReleased
        String buscar = clave.getText();
        buscarA(buscar);
    }//GEN-LAST:event_claveKeyReleased

    private void montoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_montoKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if ((c < '0' || c > '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_montoKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PagoColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PagoColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PagoColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PagoColegiatura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PagoColegiatura().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonProp;
    private javax.swing.JTextField clave;
    private javax.swing.JTextField cubrir;
    private javax.swing.JTextField fecha;
    private javax.swing.JTextField folio;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField monto;
    private javax.swing.JTextField nombre1;
    private javax.swing.JComboBox<String> status;
    private javax.swing.JLabel tituloFondo;
    private javax.swing.JLabel tituloFondo1;
    // End of variables declaration//GEN-END:variables
}
