/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author KAMBALAM
 */
public class PagoInscripcion extends javax.swing.JFrame {
    static ResultSet resu;
    static Statement sente;
    static Connection con;
    DefaultListModel modelo = new DefaultListModel();
    private String cveAlu="",cveTutor="",idAlu="",monto="";
    private int total=0;
    /**
     * Creates new form PagoInscripcion
     */
    public PagoInscripcion(String datosT,String datosA,String[] lista) {
        initComponents();
        nomT.setText(datosT);
        nomA.setText(datosA);
        listadis.removeAll();
        int cant=lista.length;
        
        for(int i=0;i<lista.length;i++){
            modelo.addElement(lista[i]);
        }
        listadis.setModel(modelo);
        
        try {
        conecta();     
        String q="Select max(cve_alumno),id_alumno from alumno";
        resu=sente.executeQuery(q);
            while (resu.next()){
                cveAlu=(resu.getString("max(cve_alumno)"));
                idAlu=(resu.getString("id_alumno"));
                
         String q1="Select max(cve_tutor) from tutor";
            resu=sente.executeQuery(q1);
            
            while (resu.next()){
                cveTutor=(resu.getString("max(cve_tutor)"));
            }        
            }
        
        String montoQ="select precioinc_ch from costohorario where cantidad_ch="+cant;
        resu=sente.executeQuery(montoQ);
            
         while (resu.next()){
                monto=(resu.getString("precioinc_ch"));
         }        
         total=Integer.parseInt(monto);   
         total1.setText(total1.getText()+" "+total);
        } catch (Exception e) {
        }
        
        
        
    }

    private PagoInscripcion() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    public void conecta(){
        String bd="mydb";
        String url="jdbc:mysql://localhost/"+bd;
        String user="root";
        String password="root";
        
        try {
            con=DriverManager.getConnection(url,user,password);
            sente=con.createStatement();
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error, no conectó "+e);
        }
    
      
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        listadis = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nomA = new javax.swing.JLabel();
        nomT = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        botonProp = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        total1 = new javax.swing.JLabel();
        tituloFondo1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        listadis.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listadis);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 208, 540, 250));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PAGO INSCRIPCÓN");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 570, 40));
        jLabel1.getAccessibleContext().setAccessibleName("                        REGISTR DE HORARIOS");

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ESCUELA DE DANZA");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 170, 30));

        nomA.setBackground(new java.awt.Color(255, 255, 255));
        nomA.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nomA.setForeground(new java.awt.Color(255, 255, 255));
        nomA.setText("Datos Alumno:");
        getContentPane().add(nomA, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 150, 30));

        nomT.setBackground(new java.awt.Color(255, 255, 255));
        nomT.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nomT.setForeground(new java.awt.Color(255, 255, 255));
        nomT.setText("Nombre Tutor:");
        getContentPane().add(nomT, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 150, 30));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("PESOS");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 480, 80, 30));

        botonProp.setBackground(new java.awt.Color(0, 102, 153));
        botonProp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        botonProp.setText("CONTINUAR");
        botonProp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPropActionPerformed(evt);
            }
        });
        getContentPane().add(botonProp, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 540, 130, 40));

        jButton1.setBackground(new java.awt.Color(253, 82, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, 130, 40));

        total1.setBackground(new java.awt.Color(255, 255, 255));
        total1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        total1.setForeground(new java.awt.Color(255, 255, 255));
        total1.setText("MONTO:");
        getContentPane().add(total1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, 210, 30));

        tituloFondo1.setBackground(new java.awt.Color(153, 0, 51));
        tituloFondo1.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo1.setOpaque(true);
        getContentPane().add(tituloFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 590));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonPropActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPropActionPerformed
        int llave1;
        PreparedStatement pst,pst2;
        try {
          conecta();
            
            String query="insert into pago (fecha_pago,monto_pago,Tutor_cve_tutor) values (curdate(),"+total+","+cveTutor+");";
            pst=con.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            if (pst.executeUpdate()==1){
                ResultSet ides=pst.getGeneratedKeys();
                if(ides!=null && ides.next()){
                    llave1=ides.getInt(1);
                    JOptionPane.showMessageDialog(null,"Llave1: "+llave1);
                    String query2="insert into inscripcion (fecha_ins,pago_folio_pago,Alumno_cve_alumno,Empleado_cve_empleado) "
                            + "values (curdate(),"+llave1+","+cveAlu+",1);";
                    pst2=con.prepareStatement(query2,PreparedStatement.RETURN_GENERATED_KEYS);
                    if (pst2.executeUpdate()==1){
                        Principal p= new Principal();
                        p.setVisible(true);
                        this.setVisible(false);
                        JOptionPane.showMessageDialog(null,"Exito al guardar","Exito",JOptionPane.INFORMATION_MESSAGE);
                    }
                }   
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error "+e);
        }
    }//GEN-LAST:event_botonPropActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Principal vp=new Principal();
        vp.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PagoInscripcion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PagoInscripcion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PagoInscripcion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PagoInscripcion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PagoInscripcion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonProp;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listadis;
    private javax.swing.JLabel nomA;
    private javax.swing.JLabel nomT;
    private javax.swing.JLabel tituloFondo1;
    private javax.swing.JLabel total1;
    // End of variables declaration//GEN-END:variables
}
