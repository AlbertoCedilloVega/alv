package danza;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class RegistroHorarios extends javax.swing.JFrame {
 static Connection con=null;
 static Statement sente;
 static ResultSet resu;
 DefaultTableModel modelo;
    public RegistroHorarios() {
        initComponents();
        modelo=(DefaultTableModel) horario.getModel();
        
        String bd ="mydb";    
        String url="jdbc:mysql://localhost/"+bd;
        String user="root";
        String pass="root";
            try {
                con = DriverManager.getConnection(url,user,pass);
                sente=con.createStatement();
            
                System.out.print("Conectado");
            } catch (Exception e) {
                System.out.print(e);
            }
            
            
        maestros.removeAllItems();
        aulas.removeAllItems();
        disciplinas.removeAllItems();
        
        //__________________________________________________________________________________________________
        try{
            String  maestrosQ="select * from persona join empleado on persona.cve_persona = "
                    + "empleado.Persona_cve_persona and empleado.tipo_empleado='MAESTRO'";  
            resu=sente.executeQuery(maestrosQ);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al conseguir maestros\n"+e); 
        }
        try{
            while(resu.next()){
            maestros.addItem(resu.getString("cve_empleado")+"     "+resu.getString("nom_persona")+
                    " "+resu.getString("ap_persona"));
        }
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al asignar maestros\n"+e); 
        }
        //__________________________________________________________________________________________________
        try{
            String  aulasQ="select * from aula";  
            resu=sente.executeQuery(aulasQ);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al conseguir aulas\n"+e); 
        }
        try{
            while(resu.next()){
            aulas.addItem(resu.getString("cve_aula")+"     "+resu.getString("nombre_aula"));
        }
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al asignar aulas\n"+e); 
        }
        //__________________________________________________________________________________________________
        try{
            String  aulasQ="select * from disciplina where status_dis='activo'";  
            resu=sente.executeQuery(aulasQ);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al conseguir dis\n"+e); 
        }
        try{
            while(resu.next()){
            disciplinas.addItem(resu.getString("cve_dis")+"     "+resu.getString("nom_dis"));
            
        }
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al asignar dis\n"+e); 
        }
        
        String buscaDisciplina="select * from disciplina join empleado join persona join aula join horariomaestro "
            + "on disciplina.cve_dis=horariomaestro.disciplina_cve_dis and empleado.cve_empleado=horariomaestro.empleado_cve_empleado "
            + "and aula.cve_aula=horariomaestro.Aula_cve_aula and persona.cve_persona = empleado.Persona_cve_persona where YEAR(horariomaestro.fecha_ini)=YEAR(curdate())";
            
        try{ 
            resu=sente.executeQuery(buscaDisciplina);
            
            while(resu.next()){
                 modelo.addRow(new String[]{
                  resu.getString("num_horario"),resu.getString("cve_dis")+"    "+resu.getString("nom_dis"),
                 (resu.getString("cve_empleado")+"     "+resu.getString("nom_persona")+" "+resu.getString("ap_persona")),
                  resu.getString("hora_horario"),resu.getString("cve_aula")+"  "+resu.getString("nombre_aula"),
                  resu.getString("grado_horario"),resu.getString("dia_horario")
                 }); 
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al llenar la tabla1\n"+e); 
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        horario = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        maestros = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        aulas = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        grados = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        disciplinas = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        cancelar = new javax.swing.JButton();
        agregar = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        dia = new javax.swing.JComboBox<>();
        hora = new javax.swing.JComboBox<>();
        min = new javax.swing.JComboBox<>();
        eliminar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REGISTRO DE HORARIOS");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1080, 40));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        horario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CVE.DIS.", "DISCIPLINA", "MAESTRO", "HORA", "AULA", "GRADO", "DIA"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        horario.setRowHeight(20);
        jScrollPane3.setViewportView(horario);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, 650, 370));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Maestro :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 90, 30));

        maestros.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(maestros, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 190, 30));

        jButton2.setText("+");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, 40, 30));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Aula:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 40, 30));

        aulas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(aulas, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 130, 120, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Grado :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 130, 60, 30));

        grados.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2" }));
        jPanel1.add(grados, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 50, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Disciplina:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 90, 30));

        disciplinas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(disciplinas, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 190, 30));

        jButton3.setText("+");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 40, 30));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Hora Inicio:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 100, 30));

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText(":");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, 10, 30));

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Dia: ");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 300, -1, 30));

        cancelar.setBackground(new java.awt.Color(253, 82, 0));
        cancelar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cancelar.setText("CERRAR");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        jPanel1.add(cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 110, 40));

        agregar.setBackground(new java.awt.Color(0, 102, 153));
        agregar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        agregar.setText("AGREGAR DISCIPLINA");
        agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarActionPerformed(evt);
            }
        });
        jPanel1.add(agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 470, -1, 40));

        guardar.setBackground(new java.awt.Color(0, 102, 153));
        guardar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        guardar.setText("GUARDAR HORARIO");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        jPanel1.add(guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 470, -1, 40));

        dia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES" }));
        jPanel1.add(dia, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 190, -1));

        hora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel1.add(hora, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 70, 30));

        min.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "15", "30", "45" }));
        jPanel1.add(min, new org.netbeans.lib.awtextra.AbsoluteConstraints(229, 250, 70, 30));

        eliminar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        eliminar.setText("ELIMINAR");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        jPanel1.add(eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 470, -1, 40));

        jButton1.setText("Imprimir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 470, -1, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
    this.setVisible(false);
    Principal p= new Principal();
    p.setVisible(true);
    }//GEN-LAST:event_cancelarActionPerformed
    public void agregar(){
    String horaS="0"+hora.getSelectedItem().toString()+":"+min.getSelectedItem().toString()+":00";
    String diaS="";
    if (dia.getSelectedItem().toString().equals("LUNES")){
        diaS="Lunes"; 
    }
    if (dia.getSelectedItem().toString().equals("MARTES")){
        diaS="Martes";
    }
    if (dia.getSelectedItem().toString().equals("MIERCOLES")){
        diaS="Miercoles";
    }
    if (dia.getSelectedItem().toString().equals("JUEVES")){
        diaS="Jueves";
    }
    if (dia.getSelectedItem().toString().equals("VIERNES")){
        diaS="Viernes";
    }
    boolean bandera=false;
    if(modelo.getRowCount()==0){
        modelo.addRow(new String[]{"null",disciplinas.getSelectedItem().toString(),maestros.getSelectedItem().toString(),
            horaS,aulas.getSelectedItem().toString(),
        grados.getSelectedItem().toString(),diaS});  
    }else{
    for(int i=0;i<modelo.getRowCount();i++){
    if(((modelo.getValueAt(i, 2).toString().substring(0,2).equals(maestros.getSelectedItem().toString().substring(0,2)))||
        (modelo.getValueAt(i, 4).equals(aulas.getSelectedItem().toString())))&&
        (modelo.getValueAt(i, 3).equals(horaS))&&
        (modelo.getValueAt(i, 6).equals(diaS))){
       JOptionPane.showMessageDialog(null, "El maestro o el aula ya tienen asignada una materia a esa hora en ese dia");  
       bandera=true;
    }
    }
    if (bandera==false){
        modelo.addRow(new String[]{"null",disciplinas.getSelectedItem().toString(),maestros.getSelectedItem().toString(),horaS,aulas.getSelectedItem().toString(),
        grados.getSelectedItem().toString(),diaS});
    }
    }   
    }
    private void agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarActionPerformed
    this.agregar();
    }//GEN-LAST:event_agregarActionPerformed
    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
    for(int i=0;i<modelo.getRowCount();i++){
        if((modelo.getValueAt(i, 0)).equals("null")){ 
            try {
                String guardarHorario="insert into horariomaestro values(null,'"+modelo.getValueAt(i, 3)+
                    "',"+modelo.getValueAt(i, 5)+",'"+modelo.getValueAt(i, 6)+"','Activa',"+modelo.getValueAt(i,4).toString().substring(0,2)+","
                    +modelo.getValueAt(i,2).toString().substring(0,2)+","+modelo.getValueAt(i,1).toString().substring(0,2)+",curdate(), ADDDATE(curdate(), INTERVAL 1 YEAR))";
                JOptionPane.showMessageDialog(null, "Renglon "+i+" guardado");  
                System.out.println(guardarHorario);
                sente.execute(guardarHorario);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al escribir los datos\n"+e); 
            }
        }
    }
     Principal p=new Principal();
     this.setVisible(false);
     p.setVisible(true);
    }//GEN-LAST:event_guardarActionPerformed
    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        int fila = horario.getSelectedRow();
        System.out.println(fila);  
        if (fila == -1) {  
        
        JOptionPane.showMessageDialog(this, "No hay registro seleccionado");
        }else{
        if(modelo.getValueAt(fila,0).toString().equals("null")){ 
             DefaultTableModel m=(DefaultTableModel) horario.getModel();
        m.removeRow(fila);
        }else{
          JOptionPane.showMessageDialog(this, "No puede eliminar datos guardados en la base");  
        }  
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         RegistroEmpleado re = new RegistroEmpleado();
        re.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        RegistroDisciplina rD=new RegistroDisciplina();
        rD.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       try {
            MessageFormat mensajeTitulo= new MessageFormat("Horario General");
            
            MessageFormat mensajePie= new MessageFormat("Ciclo escolar : 2018 - 2019");
            horario.print(JTable.PrintMode.FIT_WIDTH,mensajeTitulo,mensajePie);
        } catch (Exception e) {
        
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroHorarios().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton agregar;
    private javax.swing.JComboBox<String> aulas;
    private javax.swing.JButton cancelar;
    private javax.swing.JComboBox<String> dia;
    private javax.swing.JComboBox<String> disciplinas;
    private javax.swing.JButton eliminar;
    private javax.swing.JComboBox<String> grados;
    private javax.swing.JButton guardar;
    private javax.swing.JComboBox<String> hora;
    private javax.swing.JTable horario;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JComboBox<String> maestros;
    private javax.swing.JComboBox<String> min;
    // End of variables declaration//GEN-END:variables
}