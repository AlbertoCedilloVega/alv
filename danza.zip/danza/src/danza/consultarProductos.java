/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;

import codigo.operacion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author KAMBALAM
 */
public class consultarProductos extends javax.swing.JFrame {
//    DefaultTableModel model=new DefaultTableModel(){
//    @Override
//        public boolean isCellEditable(int row,int colum){
//            return false;
//        }
//    };
//    DefaultTableModel model1=new DefaultTableModel(){
//    @Override
//        public boolean isCellEditable(int row,int colum){
//            return false;
//        }
//    };
    private int co =0;
    private double com=0.0,ven=0.0;
    static Connection con=null;
    static Statement sente;
    static ResultSet resu;

    /**
     * Creates new form consultarProductos
     */
    public consultarProductos() {
        initComponents();
        buscar();
    }
    public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print(e);
        }
    }
//    void llenart(){
//        model.addRow(new Object[]{
////         codigox.getText(),nombre.getText(),talla.getSelectedItem().toString(),
////            surtida.getValue(),precio.getText()
//            
//        });
//    }
    public void buscar(){
        DefaultTableModel model=new DefaultTableModel(){
    @Override
        public boolean isCellEditable(int row,int colum){
            return false;
        }
    };
        String q="select cve_kardex,nom_producto,marca_producto,talla_talla,nombre_prov,cant_kardex,min_kardex,max_kardex,precio_precio_pro,compra_precio_pro from precio_producto join (select max(num_precio_pro) as m from precio_producto group by kardex_cve_kardex)as x join producto join kardex join talla join proveedor on precio_producto.num_precio_pro=x.m and kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex and kardex.talla_cve_talla=talla.cve_talla and kardex.proveedor_id_prov=proveedor.id_prov where precio_producto.num_precio_pro=x.m ;";
        try {
            conecta();
            String [] titu=new String[] {"Cv Producto","Nombre","Marca","Talla","Proveedor","Cantidad","Stok min","Stock max","Precio Venta","Precio Compra"};
            resu=sente.executeQuery(q);
            model.setColumnIdentifiers(titu);
            String [] fila=new String [10];
            while(resu.next()){
                fila[0]=resu.getString("cve_kardex");
                fila[1]=resu.getString("nom_producto");
                fila[2]=resu.getString("marca_producto");
                fila[3]=resu.getString("talla_talla");
                fila[4]=resu.getString("nombre_prov");
                fila[5]=resu.getString("cant_kardex");
                fila[6]=resu.getString("min_kardex");
                fila[7]=resu.getString("max_kardex");
                fila[8]=resu.getString("precio_precio_pro");
                fila[9]=resu.getString("compra_precio_pro");
                model.addRow(fila);
            }
            jTable1.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al consultar"+ e,"Error",JOptionPane.ERROR_MESSAGE);
        }
        
        
        System.out.println(q);
    }
    public void buscar1(String no){
        DefaultTableModel model=new DefaultTableModel(){
        @Override
            public boolean isCellEditable(int row,int colum){
                return false;
            }
        };
        String q="select cve_kardex,nom_producto,marca_producto,talla_talla,nombre_prov,cant_kardex,min_kardex,max_kardex,precio_precio_pro,compra_precio_pro from precio_producto join (select max(num_precio_pro) as m from precio_producto group by kardex_cve_kardex)as x join producto join kardex join talla join proveedor on precio_producto.num_precio_pro=x.m and kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex and kardex.talla_cve_talla=talla.cve_talla and kardex.proveedor_id_prov=proveedor.id_prov where precio_producto.num_precio_pro=x.m and nom_producto like"+'"'+no+"_%"+'"'+";";//nombre_prov like "+'"'+texto+"_%"+'"'+";"
        try {
            conecta();
            String [] titu=new String[] {"Cv Producto","Nombre","Marca","Talla","Proveedor","Cantidad","Stok min","Stock max","Precio Venta","Precio Compra"};
            resu=sente.executeQuery(q);
            model.setColumnIdentifiers(titu);
            String [] fila=new String [10];
            while(resu.next()){
                fila[0]=resu.getString("cve_kardex");
                fila[1]=resu.getString("nom_producto");
                fila[2]=resu.getString("marca_producto");
                fila[3]=resu.getString("talla_talla");
                fila[4]=resu.getString("nombre_prov");
                fila[5]=resu.getString("cant_kardex");
                fila[6]=resu.getString("min_kardex");
                fila[7]=resu.getString("max_kardex");
                fila[8]=resu.getString("precio_precio_pro");
                fila[9]=resu.getString("compra_precio_pro");
                model.addRow(fila);
            }
            jTable1.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al consultar"+ e,"Error",JOptionPane.ERROR_MESSAGE);
        }
        
        
        System.out.println(q);
    }
    public void buscar2(String cv){
        DefaultTableModel model=new DefaultTableModel(){
        @Override
            public boolean isCellEditable(int row,int colum){
                return false;
            }
        };
        String q="select cve_kardex,nom_producto,marca_producto,talla_talla,nombre_prov,cant_kardex,min_kardex,max_kardex,precio_precio_pro,compra_precio_pro from precio_producto join (select max(num_precio_pro) as m from precio_producto group by kardex_cve_kardex)as x join producto join kardex join talla join proveedor on precio_producto.num_precio_pro=x.m and kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex and kardex.talla_cve_talla=talla.cve_talla and kardex.proveedor_id_prov=proveedor.id_prov where precio_producto.num_precio_pro=x.m and cve_kardex="+'"'+cv+'"'+";";//nombre_prov like "+'"'+texto+"_%"+'"'+";"
        try {
            conecta();
            String [] titu=new String[] {"Cv Producto","Nombre","Marca","Talla","Proveedor","Cantidad","Stok min","Stock max","Precio Venta","Precio Compra"};
            resu=sente.executeQuery(q);
            model.setColumnIdentifiers(titu);
            String [] fila=new String [10];
            while(resu.next()){
                fila[0]=resu.getString("cve_kardex");
                fila[1]=resu.getString("nom_producto");
                fila[2]=resu.getString("marca_producto");
                fila[3]=resu.getString("talla_talla");
                fila[4]=resu.getString("nombre_prov");
                fila[5]=resu.getString("cant_kardex");
                fila[6]=resu.getString("min_kardex");
                fila[7]=resu.getString("max_kardex");
                fila[8]=resu.getString("precio_precio_pro");
                fila[9]=resu.getString("compra_precio_pro");
                model.addRow(fila);
            }
            jTable1.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al consultar"+ e,"Error",JOptionPane.ERROR_MESSAGE);
        }
        
        
        System.out.println(q);
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel24 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        cancelarrpro = new javax.swing.JButton();
        nom = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cve = new javax.swing.JTextField();
        tituloFondo1 = new javax.swing.JLabel();
        tituloFondo3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setBackground(new java.awt.Color(51, 51, 51));
        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("CONSULTA DE PRODUCTO");
        jLabel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel24.setOpaque(true);
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 900, 40));

        jTable1.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cve Producto", "Nombre", "Marca", "Talla", "Proveedor", "Cantidad", "Stock Min", "Stock Max", "P.Venta", "P.Compra"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 900, 290));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Buscar por Clave");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, 160, 30));

        cancelarrpro.setBackground(new java.awt.Color(204, 0, 0));
        cancelarrpro.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cancelarrpro.setText("Cancalar");
        cancelarrpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarrproActionPerformed(evt);
            }
        });
        getContentPane().add(cancelarrpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 140, 150, 40));

        nom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nomKeyReleased(evt);
            }
        });
        getContentPane().add(nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 90, 200, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Buscar por Nombre");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 160, 30));

        cve.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cveKeyReleased(evt);
            }
        });
        getContentPane().add(cve, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, 200, 30));

        tituloFondo1.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo1.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tituloFondo1.setOpaque(true);
        getContentPane().add(tituloFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 900, 140));

        tituloFondo3.setBackground(new java.awt.Color(153, 0, 51));
        tituloFondo3.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo3.setOpaque(true);
        getContentPane().add(tituloFondo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nomKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomKeyReleased
        String no=nom.getText();
        buscar1(no);
    }//GEN-LAST:event_nomKeyReleased

    private void cveKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cveKeyReleased
        // TODO add your handling code here:
        if (cve.getText().equals("")){
            buscar();
        }else{
        String cv=cve.getText();
        buscar2(cv);
        }
    }//GEN-LAST:event_cveKeyReleased

    private void cancelarrproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarrproActionPerformed
        int res = JOptionPane.showConfirmDialog(null,"¿Desea Regresar al Menu principal?\n","Advertencia",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (res == JOptionPane.YES_OPTION) {
            operacion.cancelarTransaccion();
            Principal vp = new Principal();
            vp.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_cancelarrproActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(consultarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(consultarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(consultarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(consultarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new consultarProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelarrpro;
    private javax.swing.JTextField cve;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nom;
    private javax.swing.JLabel tituloFondo1;
    private javax.swing.JLabel tituloFondo3;
    // End of variables declaration//GEN-END:variables
}
