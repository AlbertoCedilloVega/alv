/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;

import codigo.operacion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author KAMBALAM
 */
public class pedidos extends javax.swing.JFrame {
    DefaultTableModel model=new DefaultTableModel(){
    @Override
        public boolean isCellEditable(int row,int colum){
            return false;
        }
    };
    private int co =0;
    private double com=0.0,ven=0.0;
    static Connection con=null;
    static Statement sente;
    static ResultSet resu;

    /**
     * Creates new form pedidos
     */
    public pedidos() {
        initComponents();
        String [] titu=new String[] {"Cv Producto","Nombre","Talla","Cantidad","Precio de Venta"};
        model.setColumnIdentifiers(titu);
        jTable1.setModel(model);
        fechapro.setText(fechactu());
        fechapro.setEditable(false);
        talla.setEnabled(false);
        busmarc.setEnabled(false);
    }
    void llenart(){
        model.addRow(new Object[]{
         codigox.getText(),nombre.getText(),talla.getSelectedItem().toString(),
            surtida.getValue(),precio.getText()
            
        });
        
       
    }
    public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print(e);
        }
    }
    public static String fechactu(){
    Date now = new Date(System.currentTimeMillis());
        SimpleDateFormat date = new SimpleDateFormat("YYY-MM-dd");
        SimpleDateFormat hour = new SimpleDateFormat("HH:mm:ss");
        return date.format(now);
        
   
    }
    public void buscacod(String c){
        String q="select nom_producto,precio_precio_pro,marca_producto,talla_talla,cant_kardex from kardex join producto join precio_producto "
                + "join talla on kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex "
                + "and kardex.talla_cve_talla=talla.cve_talla where cve_producto="+'"'+c+'"'+";";
        try {
            conecta();
            System.out.println(q);
            resu=sente.executeQuery(q);
            talla.removeAllItems();
            while(resu.next()){
                nombre.setText(resu.getString("nom_producto"));
                marca.setText(resu.getString("marca_producto"));
                precio.setText(resu.getString("precio_precio_pro"));
                talla.addItem(resu.getString("talla_talla"));
                existencia.setText(resu.getString("cant_kardex"));
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al buscar por codigo\n"+e,"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    public void buscamarcta(String n,String t,String m){
        String q="select cve_kardex,precio_precio_pro,cant_kardex from kardex join producto join precio_producto join talla on "
                + "kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex "
                + "and kardex.talla_cve_talla=talla.cve_talla where nom_producto="+'"'+n+'"'+"and marca_producto="+'"'+m+'"'+"and talla_talla="+'"'+t+'"'+";";
        
        try {
            conecta();
            resu=sente.executeQuery(q);
            while(resu.next()){
                codigox.setText(resu.getString("cve_kardex"));
                precio.setText(resu.getString("precio_precio_pro"));
                existencia.setText(resu.getString("cant_kardex"));
            }
        } catch (Exception e) {
              JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al buscar por nombre\n"+e,"Error",JOptionPane.ERROR_MESSAGE);
        }
        
    }
    public void buscamarc(String n,String m){
        String q="select talla_talla from kardex join producto join precio_producto join talla on kardex.producto_cve_producto=producto.cve_producto "
                + "and precio_producto.kardex_cve_kardex=kardex.cve_kardex and kardex.talla_cve_talla=talla.cve_talla where "
                + "nom_producto="+'"'+n+'"'+"and marca_producto="+'"'+m+'"'+"group by talla_talla"+";";
        try {
            conecta();
            resu=sente.executeQuery(q);
            System.out.println(q);
            talla.removeAllItems();
            while(resu.next()){
                talla.addItem(resu.getString("talla_talla"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al buscar por marca\n"+e,"Error",JOptionPane.ERROR_MESSAGE);
        }
        
    }
    public void guardar(){
        int llave;
        PreparedStatement pst;
        PreparedStatement pst1;
        try {
            conecta();
            int filas=model.getRowCount();
            String q="insert into pedido (fecha_pedido,total_pedido,status_pedido) values ('"+fechapro.getText()+"','"+total.getText()+"','PENDIENTE');";
            pst=con.prepareStatement(q,PreparedStatement.RETURN_GENERATED_KEYS);
            if(pst.executeUpdate()==1){
                ResultSet ides= pst.getGeneratedKeys();
                if (ides!=null && ides.next()){
                    llave=ides.getInt(1);
                    for(int i=0;i<filas;i++){
                    String q1="insert into renglon_ped (cant_renped,costo_renped,pedido_folio_pedido,kardex_cve_kardex) values ('"+jTable1.getValueAt(i, 3).toString()+"','"+jTable1.getValueAt(i, 4).toString()+"','"+llave+"','"+jTable1.getValueAt(i,0).toString()+"');";
                    pst.executeUpdate(q1);
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"A ocurriodo un error al registrar su pedido"+e,"Error",JOptionPane.ERROR_MESSAGE);
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel34 = new javax.swing.JLabel();
        codigox = new javax.swing.JTextField();
        cod = new javax.swing.JCheckBox();
        buscx = new javax.swing.JButton();
        nombre = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        marca = new javax.swing.JTextField();
        busmarc = new javax.swing.JButton();
        Buscarpro = new javax.swing.JButton();
        talla = new javax.swing.JComboBox<>();
        jLabel44 = new javax.swing.JLabel();
        precio = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        surtida = new javax.swing.JSpinner();
        existencia = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        Agregar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        fechapro = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        folio = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        total = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        imprimirfac = new javax.swing.JButton();
        cancelarrpro = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel24 = new javax.swing.JLabel();
        tituloFondo1 = new javax.swing.JLabel();
        tituloFondo3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("PRODUCTO");
        getContentPane().add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 100, 30));
        getContentPane().add(codigox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 190, 30));

        cod.setBackground(new java.awt.Color(51, 51, 51));
        cod.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cod.setForeground(new java.awt.Color(255, 255, 255));
        cod.setSelected(true);
        cod.setText("Codigo");
        cod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codActionPerformed(evt);
            }
        });
        getContentPane().add(cod, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 90, 30));

        buscx.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ima/lupa2.png"))); // NOI18N
        buscx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscxActionPerformed(evt);
            }
        });
        getContentPane().add(buscx, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 100, 30, 30));
        getContentPane().add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 190, 30));

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Nombre :");
        getContentPane().add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, 30));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Marca:");
        getContentPane().add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 90, 30));
        getContentPane().add(marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 190, 30));

        busmarc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ima/lupa2.png"))); // NOI18N
        busmarc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busmarcActionPerformed(evt);
            }
        });
        getContentPane().add(busmarc, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 190, 30, 30));

        Buscarpro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ima/lupa2.png"))); // NOI18N
        Buscarpro.setText("Buscar");
        Buscarpro.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Buscarpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarproActionPerformed(evt);
            }
        });
        getContentPane().add(Buscarpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 230, 110, 30));

        talla.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                tallaPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        talla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tallaActionPerformed(evt);
            }
        });
        getContentPane().add(talla, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 110, 30));

        jLabel44.setBackground(new java.awt.Color(255, 255, 255));
        jLabel44.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("Talla:");
        getContentPane().add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 50, 30));

        precio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                precioKeyTyped(evt);
            }
        });
        getContentPane().add(precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 230, 80, 30));

        jLabel43.setBackground(new java.awt.Color(255, 255, 255));
        jLabel43.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Costo:");
        getContentPane().add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 230, -1, 30));

        jLabel48.setBackground(new java.awt.Color(255, 255, 255));
        jLabel48.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("Cantidad:");
        getContentPane().add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 80, 30));

        surtida.setBorder(null);
        getContentPane().add(surtida, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 190, 80, 30));

        existencia.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        existencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                existenciaActionPerformed(evt);
            }
        });
        existencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                existenciaKeyTyped(evt);
            }
        });
        getContentPane().add(existencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 140, 80, 30));

        jLabel40.setBackground(new java.awt.Color(255, 255, 255));
        jLabel40.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Existencia:");
        getContentPane().add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 140, 90, 30));

        Agregar.setBackground(new java.awt.Color(0, 204, 0));
        Agregar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Agregar.setText("Agregar");
        Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarActionPerformed(evt);
            }
        });
        getContentPane().add(Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 150, 150, 40));

        eliminar.setBackground(new java.awt.Color(204, 0, 0));
        eliminar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        getContentPane().add(eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 210, 150, 40));

        fechapro.setEditable(false);
        fechapro.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fechapro.setText(" ");
        fechapro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fechaproActionPerformed(evt);
            }
        });
        getContentPane().add(fechapro, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 70, 120, -1));

        jLabel32.setBackground(new java.awt.Color(255, 255, 255));
        jLabel32.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Fecha:");
        getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 70, -1, 30));

        folio.setEditable(false);
        folio.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        folio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                folioActionPerformed(evt);
            }
        });
        folio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                folioKeyTyped(evt);
            }
        });
        getContentPane().add(folio, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, 110, -1));

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Folio:");
        getContentPane().add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 50, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Clave del producto", "Nombre del producto", "Talla", "Precio venta", "Cantidad"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 730, 290));

        total.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        total.setText("0");
        total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalActionPerformed(evt);
            }
        });
        total.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                totalKeyTyped(evt);
            }
        });
        getContentPane().add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 570, 120, 30));

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Total:");
        getContentPane().add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 570, 70, 30));

        imprimirfac.setBackground(new java.awt.Color(0, 0, 204));
        imprimirfac.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        imprimirfac.setText("Imprimir Pedido");
        imprimirfac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imprimirfacActionPerformed(evt);
            }
        });
        getContentPane().add(imprimirfac, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 570, 160, 40));

        cancelarrpro.setBackground(new java.awt.Color(204, 0, 0));
        cancelarrpro.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cancelarrpro.setText("Cancalar");
        cancelarrpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarrproActionPerformed(evt);
            }
        });
        getContentPane().add(cancelarrpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 570, 150, 40));

        guardar.setBackground(new java.awt.Color(0, 0, 204));
        guardar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        guardar.setText("Guardar");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        getContentPane().add(guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 570, 150, 40));
        getContentPane().add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 310, 10));
        getContentPane().add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 320, 10));

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, 10, 110));

        jLabel24.setBackground(new java.awt.Color(51, 51, 51));
        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("                                                   PEDIDOS DE PRODUCTO");
        jLabel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel24.setOpaque(true);
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 770, 40));

        tituloFondo1.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo1.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tituloFondo1.setOpaque(true);
        getContentPane().add(tituloFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 770, 560));

        tituloFondo3.setBackground(new java.awt.Color(153, 0, 51));
        tituloFondo3.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo3.setOpaque(true);
        getContentPane().add(tituloFondo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 630));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void codActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codActionPerformed

        if(cod.isSelected()==true){
            nombre.setEditable(false);
            talla.setEditable(false);
            marca.setEditable(false);
            talla.setEnabled(false);
            busmarc.setEnabled(false);
            codigox.setEnabled(true);
            buscx.setEnabled(true);
            Buscarpro.setEnabled(false);
            existencia.setText("");
            surtida.setValue(0);
            precio.setText("0");
        }else{
            nombre.setEditable(true);
            talla.setEditable(true);
            marca.setEditable(true);
            talla.setEnabled(true);
            busmarc.setEnabled(true);
            codigox.setEnabled(false);
            buscx.setEnabled(false);
            Buscarpro.setEnabled(true);
            existencia.setText("");
            surtida.setValue(0);
            precio.setText("0");
        }
    }//GEN-LAST:event_codActionPerformed

    private void tallaPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_tallaPopupMenuWillBecomeInvisible
        
    }//GEN-LAST:event_tallaPopupMenuWillBecomeInvisible

    private void tallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tallaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tallaActionPerformed

    private void precioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_precioKeyTyped
        char c = evt.getKeyChar();
        if ((c < '0' || c > '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_precioKeyTyped

    private void existenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_existenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_existenciaActionPerformed

    private void existenciaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_existenciaKeyTyped

    }//GEN-LAST:event_existenciaKeyTyped

    private void AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarActionPerformed
        //int resp;
        double ven1,com1;
        if(existencia.getText().equals("")||precio.getText().equals("")||surtida.getValue().equals(0)||precio.getText().equals("0")){
            JOptionPane.showMessageDialog(null,"alguos de los campos estan vacios o tienen valor de 0");
        }else{
            if(existencia.getText().equals("0")){
                double cos=0.0,tos=0.0, to=0.0;
                int can=0;
                can=(int) surtida.getValue();
                cos=Double.parseDouble(precio.getText());
                tos=cos*can;
                to=Double.parseDouble(total.getText());
                to+=tos;
                System.out.println(can+" " +cos+" "+to);
                llenart();
                String toss=Double.toString(to);
                total.setText(toss);
                existencia.setText("");
                surtida.setValue(0);
                precio.setText("0");
            }else{
                JOptionPane.showMessageDialog(null,"El producto se encuentra en existencia");
            }
        }
    }//GEN-LAST:event_AgregarActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        double cos=0.0,tos=0.0, to=0.0,cant=0.0;
        int fsel,resp,cant1=0,fil;
        try {
            fsel=jTable1.getSelectedRow();
            System.err.println(""+fsel);
            if(fsel==-1){
                JOptionPane.showMessageDialog(null,"debe seleccionar un producto de la tabla","advertencia",JOptionPane.WARNING_MESSAGE);
            }else{
                resp=JOptionPane.showConfirmDialog(null,"¿esta seguro q desea eliminar este producto?","elimnaar",JOptionPane.YES_NO_OPTION);
                if (resp==JOptionPane.YES_OPTION){
                    cant=Double.parseDouble(jTable1.getValueAt(fsel,4).toString());
                    cos=Double.parseDouble(jTable1.getValueAt(fsel,3).toString());
                    tos=cos*cant;
                    to=Double.parseDouble(total.getText());
                    to-=tos;
                    System.out.println(cant+" " +cos+" "+to);
                    String toss=Double.toString(to);
                    total.setText(toss);
                    System.out.println(toss);
                    DefaultTableModel m = (DefaultTableModel)jTable1.getModel();
                    m.removeRow(fsel);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar","error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void fechaproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fechaproActionPerformed

    }//GEN-LAST:event_fechaproActionPerformed

    private void folioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_folioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_folioActionPerformed

    private void folioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_folioKeyTyped

    }//GEN-LAST:event_folioKeyTyped

    private void totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalActionPerformed

    private void totalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_totalKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_totalKeyTyped

    private void imprimirfacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imprimirfacActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_imprimirfacActionPerformed

    private void cancelarrproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarrproActionPerformed
        int res = JOptionPane.showConfirmDialog(null,"¿Desea cancelar el registro?\n","Advertencia",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (res == JOptionPane.YES_OPTION) {
            operacion.cancelarTransaccion();
            Principal vp = new Principal();
            vp.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_cancelarrproActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
                if (jTable1.getRowCount()>0){
                        int resp = JOptionPane.showConfirmDialog(null,"¿Esta seguro que desea guardar la Operacion?","Guardar",JOptionPane.YES_NO_OPTION);
                       if(resp==JOptionPane.YES_OPTION){
                                int filas=model.getRowCount();
                                guardar();
                                total.setText("0.0");
                                JOptionPane.showMessageDialog(null,"Guardado con exito");
                                for(int i=0;i<filas;i++){
                                       model.removeRow(0);
                                      }
                            }
                   }else{
                        System.out.println("No hay ningun elemento agreado");
                    }
    }//GEN-LAST:event_guardarActionPerformed

    private void buscxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscxActionPerformed
        String c=codigox.getText();
        buscacod(c);
    }//GEN-LAST:event_buscxActionPerformed

    private void busmarcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busmarcActionPerformed
        String n=nombre.getText();
        String m=marca.getText();
        buscamarc(n,m);
    }//GEN-LAST:event_busmarcActionPerformed

    private void BuscarproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarproActionPerformed
        String n=nombre.getText();
        String t=talla.getSelectedItem().toString();
        String m=marca.getText();
        buscamarcta(n, t,m);
    }//GEN-LAST:event_BuscarproActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pedidos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Agregar;
    private javax.swing.JButton Buscarpro;
    private javax.swing.JButton buscx;
    private javax.swing.JButton busmarc;
    private javax.swing.JButton cancelarrpro;
    private javax.swing.JCheckBox cod;
    private javax.swing.JTextField codigox;
    private javax.swing.JButton eliminar;
    private javax.swing.JTextField existencia;
    private javax.swing.JTextField fechapro;
    private javax.swing.JTextField folio;
    private javax.swing.JButton guardar;
    private javax.swing.JButton imprimirfac;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField marca;
    private javax.swing.JTextField nombre;
    private javax.swing.JTextField precio;
    private javax.swing.JSpinner surtida;
    private javax.swing.JComboBox<String> talla;
    private javax.swing.JLabel tituloFondo1;
    private javax.swing.JLabel tituloFondo3;
    private javax.swing.JTextField total;
    // End of variables declaration//GEN-END:variables
}
