package danza;

import codigo.Producto;
import codigo.operacion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
public class registroProducto extends javax.swing.JFrame {
private int limiteTel  = 10;
static Connection con=null;
    static Statement sente;
    static ResultSet resu;
    static boolean ban;
    public registroProducto() {
        initComponents();
        busca3();
        fechapro.setText(fechactu());
        fechapro.setEditable(false);
        imacod.setEditable(false);
        nomprov.setVisible(false);
        SpinnerNumberModel nm=new SpinnerNumberModel();
        nm.setMaximum(100);
        nm.setMinimum(0);
        SpinnerNumberModel nm1=new SpinnerNumberModel();
        nm1.setMaximum(100);
        nm1.setMinimum(0);
        maxpro.setModel(nm);
        minpro.setModel(nm1);
        
    }
    public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print(e);
        }
}
    public Producto setValores(){
        Producto pro;
        String fecha=fechapro.getText().toUpperCase();
        String nombrepro=nombrerpro.getText().toUpperCase();
        String marcapro=marca.getText().toUpperCase();
        String codbarpro=codigorpro.getText().toUpperCase();
        String tallapro=tallarpro.getText().toUpperCase();
        String provedorpro=nomprov.getText().toUpperCase();
        String provedorprov1=NOM12.getSelectedItem().toString();
        String telefonoprov=telprov.getText().toUpperCase();
        String representanteprov=repreprov.getText().toUpperCase();
        int cantidad=0;
        int max=(int) maxpro.getValue();
        int min=(int) minpro.getValue();
        pro=new Producto( nombrepro,marcapro, codbarpro, tallapro,provedorpro,provedorprov1,telefonoprov,representanteprov,cantidad,max,min,fecha);
        return pro;    
    }
     @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        cancelarrpro = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        gencodrpro = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        imacod = new javax.swing.JTextField();
        repreprov = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        codigorpro = new javax.swing.JTextField();
        registrarrpro = new javax.swing.JButton();
        NOM12 = new javax.swing.JComboBox<>();
        fechapro = new javax.swing.JTextField();
        nomprov = new javax.swing.JTextField();
        telprov = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel40 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        marca = new javax.swing.JTextField();
        tallarpro = new javax.swing.JTextField();
        minpro = new javax.swing.JSpinner();
        maxpro = new javax.swing.JSpinner();
        jLabel39 = new javax.swing.JLabel();
        sss = new javax.swing.JCheckBox();
        nombrerpro = new javax.swing.JTextField();
        tituloFondo1 = new javax.swing.JLabel();
        tituloFondo3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cancelarrpro.setBackground(new java.awt.Color(253, 82, 0));
        cancelarrpro.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cancelarrpro.setText("Cancelar");
        cancelarrpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarrproActionPerformed(evt);
            }
        });
        jPanel1.add(cancelarrpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 380, 100, 40));

        jLabel24.setBackground(new java.awt.Color(51, 51, 51));
        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("                                                    REGISTRO PRODUCTO");
        jLabel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel24.setOpaque(true);
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 720, 40));

        gencodrpro.setBackground(new java.awt.Color(0, 102, 153));
        gencodrpro.setFont(new java.awt.Font("Tahoma", 1, 8)); // NOI18N
        gencodrpro.setText("GENERAR CODIGO");
        gencodrpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gencodrproActionPerformed(evt);
            }
        });
        jPanel1.add(gencodrpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 220, 110, 40));

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("FECHA:");
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        imacod.setEditable(false);
        imacod.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        imacod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imacodActionPerformed(evt);
            }
        });
        jPanel1.add(imacod, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 270, 280, 90));

        repreprov.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        repreprov.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                repreprovActionPerformed(evt);
            }
        });
        repreprov.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                repreprovKeyTyped(evt);
            }
        });
        jPanel1.add(repreprov, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 330, 190, -1));

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Marca :");
        jPanel1.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, 30));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Representante:");
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 120, 30));

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Talla:");
        jPanel1.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 80, 30));

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Stock Min :");
        jPanel1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 90, -1));

        codigorpro.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        codigorpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigorproActionPerformed(evt);
            }
        });
        codigorpro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                codigorproKeyTyped(evt);
            }
        });
        jPanel1.add(codigorpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 150, 190, -1));

        registrarrpro.setBackground(new java.awt.Color(0, 102, 153));
        registrarrpro.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        registrarrpro.setText("REGISTRAR");
        registrarrpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarrproActionPerformed(evt);
            }
        });
        jPanel1.add(registrarrpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 380, 130, 40));

        NOM12.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                NOM12PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jPanel1.add(NOM12, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, 190, 30));

        fechapro.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fechapro.setText(" ");
        fechapro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fechaproActionPerformed(evt);
            }
        });
        jPanel1.add(fechapro, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 120, -1));

        nomprov.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nomprov.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomprovActionPerformed(evt);
            }
        });
        nomprov.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nomprovKeyTyped(evt);
            }
        });
        jPanel1.add(nomprov, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, 190, -1));

        telprov.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        telprov.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telprovActionPerformed(evt);
            }
        });
        telprov.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                telprovKeyTyped(evt);
            }
        });
        jPanel1.add(telprov, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 290, 190, -1));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, 240, 10));

        jLabel40.setBackground(new java.awt.Color(255, 255, 255));
        jLabel40.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("PROVEDOR");
        jPanel1.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 110, -1));

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Nombre:");
        jPanel1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 110, 30));

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Nombre :");
        jPanel1.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, 30));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Codigo :");
        jPanel1.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 90, 30));

        jLabel42.setBackground(new java.awt.Color(255, 255, 255));
        jLabel42.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Stock Max:");
        jPanel1.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 210, 100, -1));
        jPanel1.add(marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 190, 30));

        tallarpro.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tallarpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tallarproActionPerformed(evt);
            }
        });
        tallarpro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tallarproKeyTyped(evt);
            }
        });
        jPanel1.add(tallarpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 110, 190, -1));
        jPanel1.add(minpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 240, 50, 20));
        jPanel1.add(maxpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 210, 50, 20));

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Telefono:");
        jPanel1.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 110, 30));

        sss.setBackground(new java.awt.Color(51, 51, 51));
        sss.setForeground(new java.awt.Color(255, 255, 255));
        sss.setText("NEW");
        sss.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sssActionPerformed(evt);
            }
        });
        jPanel1.add(sss, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, -1, -1));

        nombrerpro.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nombrerpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombrerproActionPerformed(evt);
            }
        });
        nombrerpro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombrerproKeyTyped(evt);
            }
        });
        jPanel1.add(nombrerpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 190, -1));

        tituloFondo1.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo1.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tituloFondo1.setOpaque(true);
        jPanel1.add(tituloFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 720, 380));

        tituloFondo3.setBackground(new java.awt.Color(153, 0, 51));
        tituloFondo3.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo3.setOpaque(true);
        jPanel1.add(tituloFondo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 450));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelarrproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarrproActionPerformed
        // TODO add your handling code here:
        int res = JOptionPane.showConfirmDialog(null,"¿Desea cancelar el registro?\n","Advertencia",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (res == JOptionPane.YES_OPTION) {
        operacion.cancelarTransaccion();
        Principal vp = new Principal();
        vp.setVisible(true);
        this.setVisible(false);
        }
    }//GEN-LAST:event_cancelarrproActionPerformed

    private void gencodrproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gencodrproActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gencodrproActionPerformed

    private void imacodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imacodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_imacodActionPerformed

    private void repreprovActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_repreprovActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_repreprovActionPerformed

    private void nombrerproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombrerproActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombrerproActionPerformed

    private void registrarrproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarrproActionPerformed
        String p=nombrerpro.getText();
        String t=tallarpro.getText();
        String v;
        ban=false;
        int res = JOptionPane.showConfirmDialog(null,"¿Desea guardar el registro y salir al menu?\n","Advertencia",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (res == JOptionPane.YES_OPTION) {
            if (sss.isSelected()==true){
                v=nomprov.getText();
                buscar1(p, t, v);
                if (ban==true){
                    JOptionPane.showMessageDialog(null,"El producto ya existe","Error",JOptionPane.ERROR_MESSAGE);
                }else{
                    Producto x;
                    x= setValores();
                    operacion.insertprodu(x);
                    JOptionPane.showMessageDialog(null,"El producuto a sido registrado con exito");
                }
            }else{
                v=NOM12.getSelectedItem().toString();
                buscar1(p, t, v);
                if (ban==true){
                    JOptionPane.showMessageDialog(null,"El producto ya existe","Error",JOptionPane.ERROR_MESSAGE);
                }else{
                    Producto x;
                    x= setValores();
                    operacion.isertprodu1(x);
                    JOptionPane.showMessageDialog(null,"El producuto a sido registrado con exito");
                }
            }
        }
    }//GEN-LAST:event_registrarrproActionPerformed

    private void codigorproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigorproActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigorproActionPerformed

    private void fechaproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fechaproActionPerformed
        
        
    }//GEN-LAST:event_fechaproActionPerformed

    private void nomprovActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomprovActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomprovActionPerformed

    private void telprovActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telprovActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telprovActionPerformed

    private void nombrerproKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombrerproKeyTyped
        char c = evt.getKeyChar();
        if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')&&(c!=' ')) {
            evt.consume();
        }
    }//GEN-LAST:event_nombrerproKeyTyped

    private void codigorproKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigorproKeyTyped
         char c = evt.getKeyChar();
        if ((c < '0' || c > '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_codigorproKeyTyped

    private void nomprovKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomprovKeyTyped
        char c = evt.getKeyChar();
        if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')&&(c!=' ')) {
            evt.consume();
        }
    }//GEN-LAST:event_nomprovKeyTyped

    private void telprovKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telprovKeyTyped
        char c = evt.getKeyChar();
        if ((c < '0' || c > '9')) {
            evt.consume();
        }
        if(telprov.getText().length()==limiteTel){
             evt.consume();
        }
    }//GEN-LAST:event_telprovKeyTyped

    private void repreprovKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_repreprovKeyTyped
        char c = evt.getKeyChar();
        if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')&&(c!=' ')) {
            evt.consume();
        }
    }//GEN-LAST:event_repreprovKeyTyped

    private void tallarproKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tallarproKeyTyped
//        char c = evt.getKeyChar();
//        if ((c < '0' || c > '9')) {
//            evt.consume();
//        }
    }//GEN-LAST:event_tallarproKeyTyped

    private void tallarproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tallarproActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tallarproActionPerformed
    public boolean buscar1(String p,String t,String v){
        ban=false;
        String q="select cve_kardex from kardex join producto join talla join proveedor on kardex.producto_cve_producto=producto.cve_producto and"+
                " kardex.talla_cve_talla=talla.cve_talla and kardex.proveedor_id_prov=proveedor.id_prov where nom_producto="+'"'+p+'"'+"and nombre_prov="+'"'+v+'"'+"and talla_talla="+'"'+t+'"'+";";
        try {
            conecta();
            System.out.println(q);
            resu=sente.executeQuery(q);
            while(resu.next()){
                ban=true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error e poroducto existe"+ e);
        }
        return ban;
    }
    public void buscar4(String p){
        String q="select telefono_prov,representante_prov from proveedor where nombre_prov='"+NOM12.getSelectedItem().toString()+"';";
        try {
            conecta();
            resu=sente.executeQuery(q);
            System.out.println(q);
            while(resu.next()){
                telprov.setText(resu.getString("telefono_prov"));
                repreprov.setText(resu.getString("representante_prov"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void busca3(){
        String q="select nombre_prov from proveedor";
        try {
            conecta();
            resu=sente.executeQuery(q);
            NOM12.removeAllItems();
            while(resu.next()){
                NOM12.addItem(resu.getString("nombre_prov"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un Error al conseguir buscaprov\n"+e);
        }
        
    }
    
    
    private void sssActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sssActionPerformed
        // TODO add your handling code here:
        if(sss.isSelected()==true){
            NOM12.setVisible(false);
            nomprov.setVisible(true);
            nomprov.setText("");
            telprov.setText("");
            repreprov.setText("");
            telprov.setEnabled(true);
            repreprov.setEnabled(true);
        }else{
            busca3();
            NOM12.setVisible(true);
            nomprov.setVisible(false);
            telprov.setEnabled(false);
            repreprov.setEnabled(false);
            nomprov.setText("");
            telprov.setText("");
            repreprov.setText("");
        }
    }//GEN-LAST:event_sssActionPerformed

    private void NOM12PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_NOM12PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        String p=NOM12.getSelectedItem().toString();
        buscar4(p);
    }//GEN-LAST:event_NOM12PopupMenuWillBecomeInvisible

   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroProducto().setVisible(true);
            }
        });
    }
public static String fechactu(){
    Date now = new Date(System.currentTimeMillis());
        SimpleDateFormat date = new SimpleDateFormat("YYYY-MM-dd");
        SimpleDateFormat hour = new SimpleDateFormat("HH:mm:ss");
        return date.format(now);
        
   
} 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> NOM12;
    private javax.swing.JButton cancelarrpro;
    private javax.swing.JTextField codigorpro;
    private javax.swing.JTextField fechapro;
    private javax.swing.JButton gencodrpro;
    private javax.swing.JTextField imacod;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTextField marca;
    private javax.swing.JSpinner maxpro;
    private javax.swing.JSpinner minpro;
    private javax.swing.JTextField nombrerpro;
    private javax.swing.JTextField nomprov;
    private javax.swing.JButton registrarrpro;
    private javax.swing.JTextField repreprov;
    private javax.swing.JCheckBox sss;
    private javax.swing.JTextField tallarpro;
    private javax.swing.JTextField telprov;
    private javax.swing.JLabel tituloFondo1;
    private javax.swing.JLabel tituloFondo3;
    // End of variables declaration//GEN-END:variables
}
