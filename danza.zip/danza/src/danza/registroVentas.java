/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danza;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author KAMBALAM
 */
public class registroVentas extends javax.swing.JFrame {
    DefaultTableModel model=new DefaultTableModel(){
  @Override
    public boolean isCellEditable(int row,int colum){
        return false;
    }
};
private int co =0;
static Connection con=null;
    static Statement sente;
    static ResultSet resu;

    /**
     * Creates new form AltaVentas
     */
    public registroVentas() {
        initComponents();
        buscarfo();
        buscarpro();
        buscaemp();
        total.setText("0");
        fecha.setText(fechactu());
        fecha.setEnabled(false);
        precio.setEnabled(false);
        talla.setEnabled(false);
        cantidad.setEnabled(false);
        nombrepro.setEnabled(false);
        numventa.setText(Integer.toString(co));
        numventa.setEnabled(false);
        String [] titu=new String[] {"Clave","Producto","Cantidad","Talla","Costo"};
        model.setColumnIdentifiers(titu);
        jTable1.setModel(model);
    }
void llenart(){
        model.addRow(new Object[]{
         producto.getSelectedItem().toString(),nombrepro.getText(),cantidad.getText(),talla.getText(),precio.getText()
            
        });
        
       
    }
public static String fechactu(){
    Date now = new Date(System.currentTimeMillis());
        SimpleDateFormat date = new SimpleDateFormat("YYY-MM-dd");
        SimpleDateFormat hour = new SimpleDateFormat("HH:mm:ss");
        return date.format(now);
        
   
    }
public void buscarfo(){
    String f="select folio_ticket from ticket";
    try {
        conecta();
        resu=sente.executeQuery(f);
        while(resu.next()){
        co=Integer.parseInt(resu.getString("folio_ticket"));
        }
        co=co+1;
    } catch (Exception e) {
        System.err.println("error" +e);  
    }
}
public void buscarpro(){
    String q="select cve_producto from producto";
    
    try {
        conecta();
        resu=sente.executeQuery(q);
        producto.removeAllItems();
        while(resu.next()){
            producto.addItem(resu.getString(1));
        } 
    } catch (Exception e) {
        System.err.println("error" +e);
    }
}
public void buscas(String c){
    String q="select nom_producto,precio_precio_pro,talla_talla from kardex join producto join precio_producto join talla on kardex.producto_cve_producto=producto.cve_producto and precio_producto.kardex_cve_kardex=kardex.cve_kardex and kardex.talla_cve_talla=talla.cve_talla where cve_producto="+'"'+c+'"'+";";
    try {
        conecta();
        resu=sente.executeQuery(q);
        while(resu.next()){
            nombrepro.setText(resu.getString("nom_producto"));
            precio.setText(resu.getString("precio_precio_pro"));
            talla.setText(resu.getString("talla_talla"));
        }
    } catch (Exception e) {
        System.err.println("error"+e);
    }
}
public void buscaemp(){
    String nombre;
    String q="select cve_empleado,nom_persona,ap_persona,am_persona from persona join empleado on empleado.Persona_cve_persona=persona.cve_persona where tipo_empleado='AUXILIAR'";
    try {
        conecta();
        resu=sente.executeQuery(q);
        while (resu.next()){
            cvem.setText(resu.getString("cve_empleado"));
            nombre=(resu.getString("nom_persona")+" "+resu.getString("ap_persona")+" "+resu.getString("am_persona"));
            System.out.println(nombre);
            atiende.addItem(nombre);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,"Error al consegir los empleados"+ e,"Erro",JOptionPane.ERROR_MESSAGE);
    }
}
public void guardar(){
        int llave,llave1;
        double qc,qv,tc,tv;
        PreparedStatement pst;
        PreparedStatement pst1;
        PreparedStatement pst3;
        try {
            conecta();
            int filas=model.getRowCount();
            String q="Insert into ticket (fecha_ticket,monto_ticket,Empleado_cve_empleado) values ("+'"'+fecha.getText()+'"'+","+'"'+total.getText()+'"'+","+'"'+cvem.getText()+'"'+ ");";
            pst=con.prepareStatement(q,PreparedStatement.RETURN_GENERATED_KEYS);
            System.out.println(q);
            if (pst.executeUpdate()==1){
                ResultSet  ides=pst.getGeneratedKeys();
                System.out.println(q);
                if (ides!=null && ides.next()){
                    llave=ides.getInt(1);
                    for(int i=0;i<filas;i++){
                        System.out.println(" "+llave);
                        String q2="insert into renglon_ticket (cant_ren_ticket,costo_ren_ticket,Ticket_folio_ticket,kardex_cve_kardex) values ('"+jTable1.getValueAt(i, 2).toString()+"','"+jTable1.getValueAt(i, 4).toString()+"','"+llave+"','"+jTable1.getValueAt(i, 0).toString()+"');"; 
                        pst1=con.prepareStatement(q2,PreparedStatement.RETURN_GENERATED_KEYS);
                        if (pst1.executeUpdate()==1){
                            ResultSet ides1=pst1.getGeneratedKeys();
                            if (ides1!=null && ides1.next()){
                                llave1=ides1.getInt(1);
                                System.out.println(llave+" "+ llave1);
                                double to=0.0,ta=0.0;
                                String q4="Select cant_kardex from kardex where cve_kardex="+jTable1.getValueAt(i,0).toString()+";";
                                resu=sente.executeQuery(q4);
                                while(resu.next()){
                                    int tos;
                                    ta=Double.parseDouble(resu.getString("cant_kardex"));
                                    to=Double.parseDouble(jTable1.getValueAt(i, 2).toString());
                                    tos=(int) (ta-to);
                                    System.out.println(to);
                                    String q3="update kardex set cant_kardex="+tos+" where cve_kardex="+jTable1.getValueAt(i, 0)+";";
                                    pst3=con.prepareStatement(q3);
                                    pst3.executeUpdate();
                                    JOptionPane.showMessageDialog(null,"Guardado con exito");
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"no se pudo guardar"+e);
        }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    public static void conecta(){
    String bd ="mydb";    
    String url="jdbc:mysql://localhost/"+bd;
    String user="root";
    String pass="root";
        try {
            con = DriverManager.getConnection(url,user,pass);
            sente=con.createStatement();
            System.out.print("Conectado ");
        } catch (Exception e) {
            System.out.print(e);
        }
}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        agregar = new javax.swing.JButton();
        agregar1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        numventa = new javax.swing.JTextField();
        impirmir = new javax.swing.JButton();
        addp = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        cambio = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        recibi = new javax.swing.JTextField();
        cantidad = new javax.swing.JTextField();
        total = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        fecha = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        ncliente = new javax.swing.JTextField();
        eliminar = new javax.swing.JButton();
        producto = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        nombrepro = new javax.swing.JTextField();
        atiende = new javax.swing.JComboBox<>();
        precio = new javax.swing.JTextField();
        cvem = new javax.swing.JTextField();
        talla = new javax.swing.JTextField();
        rpago = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        tituloFondo = new javax.swing.JLabel();
        tituloFondo1 = new javax.swing.JLabel();

        agregar.setBackground(new java.awt.Color(0, 102, 153));
        agregar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        agregar.setText("  Agregar ");
        agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarActionPerformed(evt);
            }
        });

        agregar1.setBackground(new java.awt.Color(0, 102, 153));
        agregar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        agregar1.setText("  Agregar ");
        agregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregar1ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Num:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        jLabel12.setBackground(new java.awt.Color(51, 51, 51));
        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("                                                           REGISTRO VENTAS");
        jLabel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jLabel12.setOpaque(true);
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 730, 40));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre Cliente:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, 30));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Atiende :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 100, 30));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Clave P :");
        jLabel4.setToolTipText("Producto");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 80, 30));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Fecha:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 70, -1, -1));

        numventa.setEditable(false);
        numventa.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        numventa.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        numventa.setText(" ");
        numventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numventaActionPerformed(evt);
            }
        });
        getContentPane().add(numventa, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 100, -1));

        impirmir.setBackground(new java.awt.Color(0, 0, 255));
        impirmir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        impirmir.setText(" Imprimir");
        impirmir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                impirmirActionPerformed(evt);
            }
        });
        getContentPane().add(impirmir, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 560, 130, 40));

        addp.setBackground(new java.awt.Color(51, 204, 0));
        addp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        addp.setText("  Agregar ");
        addp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addpActionPerformed(evt);
            }
        });
        getContentPane().add(addp, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 560, 130, 40));

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("P/U:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 190, 40, 30));

        cambio.setEditable(false);
        cambio.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cambio.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        getContentPane().add(cambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 520, 110, -1));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Cantidad:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 90, 30));

        recibi.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        recibi.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        recibi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recibiActionPerformed(evt);
            }
        });
        getContentPane().add(recibi, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 520, 120, -1));

        cantidad.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cantidad.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        cantidad.setText("0");
        cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadActionPerformed(evt);
            }
        });
        getContentPane().add(cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 60, -1));

        total.setEditable(false);
        total.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        total.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        getContentPane().add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 520, 140, -1));

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Cambio:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 520, 70, 30));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Recibi:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 520, 60, 30));

        fecha.setEditable(false);
        fecha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fecha.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        fecha.setText(" ");
        fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fechaActionPerformed(evt);
            }
        });
        getContentPane().add(fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 70, 150, -1));

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Talla:");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 190, 50, 30));

        ncliente.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ncliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nclienteActionPerformed(evt);
            }
        });
        getContentPane().add(ncliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 220, -1));

        eliminar.setBackground(new java.awt.Color(255, 0, 0));
        eliminar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        getContentPane().add(eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 560, 130, 40));

        producto.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                productoPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productoActionPerformed(evt);
            }
        });
        getContentPane().add(producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 110, 220, 30));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Producto :");
        jLabel6.setToolTipText("Producto");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 110, 30));

        nombrepro.setEditable(false);
        getContentPane().add(nombrepro, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 150, 220, 30));

        getContentPane().add(atiende, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 220, 30));

        precio.setEditable(false);
        precio.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        precio.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        precio.setText("0");
        precio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioActionPerformed(evt);
            }
        });
        getContentPane().add(precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 190, 60, 30));
        getContentPane().add(cvem, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 150, 60, 30));

        talla.setEditable(false);
        talla.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        talla.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        talla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tallaActionPerformed(evt);
            }
        });
        getContentPane().add(talla, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 190, 70, 30));

        rpago.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ima/segu.png"))); // NOI18N
        rpago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpagoActionPerformed(evt);
            }
        });
        getContentPane().add(rpago, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 520, 30, 30));

        cancelar.setBackground(new java.awt.Color(204, 0, 0));
        cancelar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, 130, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Clave", "Producto", "Cantidad", "Talla", "Costo"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 690, 270));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Total:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 50, 30));

        tituloFondo.setBackground(new java.awt.Color(51, 51, 51));
        tituloFondo.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tituloFondo.setOpaque(true);
        getContentPane().add(tituloFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 730, 560));

        tituloFondo1.setBackground(new java.awt.Color(153, 0, 51));
        tituloFondo1.setForeground(new java.awt.Color(255, 255, 255));
        tituloFondo1.setOpaque(true);
        getContentPane().add(tituloFondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 630));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void numventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numventaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numventaActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        Principal vp=new Principal();
        vp.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    private void agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_agregarActionPerformed

    private void agregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_agregar1ActionPerformed

    private void impirmirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_impirmirActionPerformed
        int resp;
        if(cambio.getText().equals("")||recibi.getText().equals("")){
            JOptionPane.showMessageDialog(null,"no se a registrado el pago","error",JOptionPane.ERROR_MESSAGE);
        }else{
            resp=JOptionPane.showConfirmDialog(null,"¿Esta seguro que desea guradar la venta?","Guardar",JOptionPane.YES_NO_OPTION);
            if(resp==JOptionPane.YES_OPTION){
                guardar();
            }
        }
    }//GEN-LAST:event_impirmirActionPerformed

    private void addpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addpActionPerformed
        if(nombrepro.getText().equals("")||precio.getText().equals("")||cantidad.getText().equals("")||talla.getText().equals("")||ncliente.getText().equals("")||atiende.getSelectedItem().equals("")){
            JOptionPane.showMessageDialog(null,"alguos de los campos estan vacios o tienen valor de 0");
        }else{
            double cos=0.0,tos=0.0, to=0.0,can=0.0;
                    can=Double.parseDouble(cantidad.getText());
                    cos=Double.parseDouble(precio.getText());
                    tos=cos*can;
                    to=Double.parseDouble(total.getText());
                    to+=tos;
                    System.out.println(can+" " +cos+" "+to);
                    llenart();
                    String toss=Double.toString(to);
                    total.setText(toss);
                    cantidad.setEnabled(false);
                    talla.setEnabled(false);
                    precio.setEnabled(false);
                    nombrepro.setEnabled(false);
                    cantidad.setText("0");
                    talla.setText("");
                    precio.setText("0");
                    nombrepro.setText("");
        }
       
    }//GEN-LAST:event_addpActionPerformed

    private void nclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nclienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nclienteActionPerformed

    private void fechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fechaActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        double cos=0.0,tos=0.0, to=0.0,cant=0.0;
        int fsel,resp,cant1=0,fil;
        try {
            fsel=jTable1.getSelectedRow();
            System.err.println(""+fsel);
            if(fsel==-1){
                JOptionPane.showMessageDialog(null,"debe seleccionar un producto de la tabla","advertencia",JOptionPane.WARNING_MESSAGE);
            }else{
                resp=JOptionPane.showConfirmDialog(null,"¿esta seguro q desea eliminar este producto?","elimnaar",JOptionPane.YES_NO_OPTION);
                if (resp==JOptionPane.YES_OPTION){
                    cant=Double.parseDouble(jTable1.getValueAt(fsel,2).toString());
                    cos=Double.parseDouble(jTable1.getValueAt(fsel,4).toString());
                    tos=cos*cant;
                    to=Double.parseDouble(total.getText());
                    to-=tos;
                    System.out.println(cant+" " +cos+" "+to);
                    String toss=Double.toString(to);
                    total.setText(toss);
                    System.out.println(toss);
                    DefaultTableModel m = (DefaultTableModel)jTable1.getModel();
                    m.removeRow(fsel);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error al eliminar","error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void precioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioActionPerformed
        
    }//GEN-LAST:event_precioActionPerformed

    private void tallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tallaActionPerformed
        
    }//GEN-LAST:event_tallaActionPerformed

    private void productoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productoActionPerformed
        
    }//GEN-LAST:event_productoActionPerformed

    private void productoPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_productoPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        String c=producto.getSelectedItem().toString();
        buscas(c);
        precio.setEnabled(true);
        talla.setEnabled(true);
        cantidad.setEnabled(true);
    }//GEN-LAST:event_productoPopupMenuWillBecomeInvisible

    private void cantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadActionPerformed
        
    }//GEN-LAST:event_cantidadActionPerformed

    private void recibiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recibiActionPerformed
        
    }//GEN-LAST:event_recibiActionPerformed

    private void rpagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpagoActionPerformed
        double p,t,c;
        String c1;
        p=Double.parseDouble(recibi.getText());
            t=Double.parseDouble(total.getText());
            c=p-t;
            c1=Double.toString(c);
            cambio.setText(c1);
    }//GEN-LAST:event_rpagoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registroVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registroVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registroVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registroVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addp;
    private javax.swing.JButton agregar;
    private javax.swing.JButton agregar1;
    private javax.swing.JComboBox<String> atiende;
    private javax.swing.JTextField cambio;
    private javax.swing.JButton cancelar;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField cvem;
    private javax.swing.JButton eliminar;
    private javax.swing.JTextField fecha;
    private javax.swing.JButton impirmir;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField ncliente;
    private javax.swing.JTextField nombrepro;
    private javax.swing.JTextField numventa;
    private javax.swing.JTextField precio;
    private javax.swing.JComboBox<String> producto;
    private javax.swing.JTextField recibi;
    private javax.swing.JButton rpago;
    private javax.swing.JTextField talla;
    private javax.swing.JLabel tituloFondo;
    private javax.swing.JLabel tituloFondo1;
    private javax.swing.JTextField total;
    // End of variables declaration//GEN-END:variables
}
